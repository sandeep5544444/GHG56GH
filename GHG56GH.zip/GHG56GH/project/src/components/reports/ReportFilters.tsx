import React, { useState } from 'react';
import Button from '../ui/Button';

interface ReportFiltersProps {
  onFilterChange: (filters: ReportFilters) => void;
}

export interface ReportFilters {
  startDate: string;
  endDate: string;
  paymentStatus: 'all' | 'paid' | 'not_paid';
  memberId: string;
}

const ReportFilters: React.FC<ReportFiltersProps> = ({ onFilterChange }) => {
  const [filters, setFilters] = useState<ReportFilters>({
    startDate: new Date(new Date().setDate(1)).toISOString().split('T')[0], // First day of current month
    endDate: new Date().toISOString().split('T')[0], // Today
    paymentStatus: 'all',
    memberId: '',
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onFilterChange(filters);
  };
  
  const handleReset = () => {
    const resetFilters = {
      startDate: new Date(new Date().setDate(1)).toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      paymentStatus: 'all' as const,
      memberId: '',
    };
    
    setFilters(resetFilters);
    onFilterChange(resetFilters);
  };
  
  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div>
          <label 
            htmlFor="startDate" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Start Date
          </label>
          <input
            type="date"
            id="startDate"
            name="startDate"
            value={filters.startDate}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div>
          <label 
            htmlFor="endDate" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            End Date
          </label>
          <input
            type="date"
            id="endDate"
            name="endDate"
            value={filters.endDate}
            onChange={handleChange}
            min={filters.startDate}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
        
        <div>
          <label 
            htmlFor="paymentStatus" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Payment Status
          </label>
          <select
            id="paymentStatus"
            name="paymentStatus"
            value={filters.paymentStatus}
            onChange={handleChange}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All</option>
            <option value="paid">Paid</option>
            <option value="not_paid">Not Paid</option>
          </select>
        </div>
        
        <div className="self-end flex space-x-2">
          <Button type="submit" variant="primary">
            Apply Filters
          </Button>
          <Button 
            type="button" 
            variant="outline" 
            onClick={handleReset}
          >
            Reset
          </Button>
        </div>
      </div>
    </form>
  );
};

export default ReportFilters;

export { ReportFilters }