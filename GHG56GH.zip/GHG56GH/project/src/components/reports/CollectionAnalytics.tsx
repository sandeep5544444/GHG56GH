
import React from 'react';
import { TrendingUp, Users, AlertCircle } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import Card from '../ui/Card';
import { formatCurrency } from '../../utils/calculations';

const CollectionAnalytics: React.FC = () => {
  const { members, payments } = useApp();
  
  const calculateMetrics = () => {
    const today = new Date();
    const thisMonth = today.getMonth();
    const thisYear = today.getFullYear();
    
    const monthlyPayments = payments.filter(p => {
      const paymentDate = new Date(p.date);
      return paymentDate.getMonth() === thisMonth && 
             paymentDate.getFullYear() === thisYear &&
             p.status === 'paid';
    });
    
    return {
      monthlyCollection: monthlyPayments.reduce((sum, p) => sum + p.amount, 0),
      collectionRate: (monthlyPayments.length / (members.length * 30) * 100).toFixed(1),
      defaulters: members.filter(m => {
        const lastPayment = payments
          .filter(p => p.memberId === m.id && p.status === 'paid')
          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
        return !lastPayment || new Date(lastPayment.date).getMonth() !== thisMonth;
      }).length
    };
  };

  const metrics = calculateMetrics();

  return (
    <Card>
      <h2 className="text-lg font-semibold mb-4">Collection Analytics</h2>
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <TrendingUp className="text-emerald-500" size={20} />
          <div>
            <p className="text-sm text-gray-600">Monthly Collection</p>
            <p className="text-xl font-semibold">{formatCurrency(metrics.monthlyCollection)}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Users className="text-blue-500" size={20} />
          <div>
            <p className="text-sm text-gray-600">Collection Rate</p>
            <p className="text-xl font-semibold">{metrics.collectionRate}%</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <AlertCircle className="text-red-500" size={20} />
          <div>
            <p className="text-sm text-gray-600">Monthly Defaulters</p>
            <p className="text-xl font-semibold">{metrics.defaulters}</p>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default CollectionAnalytics;
