
import React from 'react';
import { Bell } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import Card from '../ui/Card';
import { formatCurrency } from '../../utils/calculations';

const DueReminders: React.FC = () => {
  const { members, payments } = useApp();
  const today = new Date();

  const getDueMembers = () => {
    return members.filter(member => {
      const lastPayment = payments
        .filter(p => p.memberId === member.id && p.status === 'paid')
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];

      if (!lastPayment) return true;

      const lastPaidDate = new Date(lastPayment.date);
      const daysSincePayment = Math.floor((today.getTime() - lastPaidDate.getTime()) / (1000 * 3600 * 24));
      return daysSincePayment >= 1;
    });
  };

  const dueMembers = getDueMembers();

  return (
    <Card>
      <div className="flex items-center gap-2 mb-4">
        <Bell className="text-amber-500" size={20} />
        <h2 className="text-lg font-semibold">Payment Reminders</h2>
      </div>
      <div className="space-y-3">
        {dueMembers.map(member => (
          <div key={member.id} className="flex justify-between items-center p-3 bg-amber-50 rounded-lg">
            <div>
              <p className="font-medium">{member.name}</p>
              <p className="text-sm text-gray-500">Due Amount: {formatCurrency(member.dailyAmount)}</p>
            </div>
            <button className="text-sm text-blue-600 hover:underline">
              Send Reminder
            </button>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default DueReminders;
