import React from 'react';
import Card from '../ui/Card';
import { formatCurrency } from '../../utils/calculations';

interface StatCardProps {
  title: string;
  value: number | string;
  icon: React.ReactNode;
  isCurrency?: boolean;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  className?: string;
}

const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  icon,
  isCurrency = false,
  trend,
  className = '',
}) => {
  const displayValue = typeof value === 'number' && isCurrency 
    ? formatCurrency(value) 
    : value;

  return (
    <Card className={`flex flex-col ${className}`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-gray-500 text-sm font-medium">{title}</h3>
        <div className="text-gray-400">{icon}</div>
      </div>

      <div className="flex items-end justify-between">
        <div>
          <p className="text-2xl font-bold text-gray-900">{displayValue}</p>

          {trend && (
            <p className={`text-sm flex items-center ${
              trend.isPositive ? 'text-green-600' : 'text-red-600'
            }`}>
              <span className="mr-1">
                {trend.isPositive ? '↑' : '↓'}
              </span>
              {trend.value}% from last month
            </p>
          )}
        </div>
      </div>
    </Card>
  );
};

export default StatCard;