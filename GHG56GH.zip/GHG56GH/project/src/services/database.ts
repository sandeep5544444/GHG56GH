
import Client from '@replit/database';

const db = new Client();

export const DatabaseService = {
  async getMembersList() {
    return await db.get('members') || [];
  },
  
  async saveMembersList(members: any[]) {
    await db.set('members', members);
  },
  
  async getPaymentsList() {
    return await db.get('payments') || [];
  },
  
  async savePaymentsList(payments: any[]) {
    await db.set('payments', payments);
  }
};
