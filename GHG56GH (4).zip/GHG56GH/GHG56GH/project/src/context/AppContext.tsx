import React, { createContext, useState, useContext, useEffect } from 'react';
import { Member, Payment } from '../types';
import { mockMembers, mockPayments } from '../utils/mockData';

interface AppContextType {
  members: Member[];
  payments: Payment[];
  addMember: (member: Omit<Member, 'id'>) => void;
  updateMember: (id: string, member: Partial<Member>) => void;
  deleteMember: (id: string) => void;
  addPayment: (payment: Omit<Payment, 'id'>) => void;
  updatePayment: (id: string, payment: Partial<Payment>) => void;
  deletePayment: (id: string) => void;
  addDocument: (memberId: string, document: Omit<Document, 'id'>) => void;
  deleteDocument: (memberId: string, documentId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [members, setMembers] = useState<Member[]>(() => {
    const savedMembers = localStorage.getItem('finance-app-members');
    return savedMembers ? JSON.parse(savedMembers) : mockMembers;
  });
  
  const [payments, setPayments] = useState<Payment[]>(() => {
    const savedPayments = localStorage.getItem('finance-app-payments');
    return savedPayments ? JSON.parse(savedPayments) : mockPayments;
  });

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem('finance-app-members', JSON.stringify(members));
  }, [members]);

  useEffect(() => {
    localStorage.setItem('finance-app-payments', JSON.stringify(payments));
  }, [payments]);

  // Member CRUD operations
  const addMember = (member: Omit<Member, 'id'>) => {
    const newMember = {
      ...member,
      id: Date.now().toString(),
    };
    setMembers(prev => [...prev, newMember]);
  };

  const updateMember = (id: string, member: Partial<Member>) => {
    setMembers(prev => 
      prev.map(m => m.id === id ? { ...m, ...member } : m)
    );
  };

  const deleteMember = (id: string) => {
    setMembers(prev => prev.filter(m => m.id !== id));
    // Also delete all payments for this member
    setPayments(prev => prev.filter(p => p.memberId !== id));
  };

  // Payment CRUD operations
  const addPayment = (payment: Omit<Payment, 'id'>) => {
    const newPayment = {
      ...payment,
      id: Date.now().toString(),
    };
    setPayments(prev => [...prev, newPayment]);
  };

  const updatePayment = (id: string, payment: Partial<Payment>) => {
    setPayments(prev =>
      prev.map(p => p.id === id ? { ...p, ...payment } : p)
    );
  };

  const deletePayment = (id: string) => {
    setPayments(prev => prev.filter(p => p.id !== id));
  };

  // Document operations
  const addDocument = (memberId: string, document: Omit<Document, 'id'>) => {
    const newDocument = {
      ...document,
      id: Date.now().toString(),
    };
    
    setMembers(prev => 
      prev.map(m => 
        m.id === memberId 
          ? { ...m, documents: [...m.documents, newDocument] } 
          : m
      )
    );
  };

  const deleteDocument = (memberId: string, documentId: string) => {
    setMembers(prev => 
      prev.map(m => 
        m.id === memberId 
          ? { ...m, documents: m.documents.filter(d => d.id !== documentId) } 
          : m
      )
    );
  };

  return (
    <AppContext.Provider value={{
      members,
      payments,
      addMember,
      updateMember,
      deleteMember,
      addPayment,
      updatePayment,
      deletePayment,
      addDocument,
      deleteDocument
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};