import React, { useState } from 'react';
import Sidebar from './Sidebar';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="flex h-screen bg-gray-100">
      <div className="md:hidden absolute top-4 left-4 z-50">
        <button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="p-2 rounded-lg bg-gray-900 text-white"
        >
          {isSidebarOpen ? '✕' : '☰'}
        </button>
      </div>
      <div className={`${isSidebarOpen ? 'block' : 'hidden'} md:block`}>
        <Sidebar onClose={() => setIsSidebarOpen(false)} />
      </div>
      <main className="flex-1 overflow-auto p-4 md:p-6 pt-16 md:pt-6">
        {children}
      </main>
    </div>
  );
};

export default Layout;