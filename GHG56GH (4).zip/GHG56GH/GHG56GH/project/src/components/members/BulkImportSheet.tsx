
import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import Button from '../ui/Button';
import Card from '../ui/Card';
import { Upload } from 'lucide-react';

const BulkImportSheet: React.FC = () => {
  const { addMember } = useApp();
  const [file, setFile] = useState<File | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleImport = async () => {
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const rows = text.split('\n');
      
      // Skip header row
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i].split(',');
        if (row.length >= 4) {
          const [serialNumber, name, mobileNumber, loanAmount] = row.map(cell => cell.trim());
          
          if (serialNumber && name && loanAmount) {
            addMember({
              name,
              mobileNumber,
              serialNumber,
              loanAmount: parseFloat(loanAmount),
              dailyAmount: Math.ceil(parseFloat(loanAmount) / 100),
              notes: 'Imported from CSV',
              documents: []
            });
          }
        }
      }
      setFile(null);
      alert('Members imported successfully');
    };
    reader.readAsText(file);
  };

  return (
    <Card>
      <h2 className="text-lg font-semibold mb-4">Import from CSV/Excel</h2>
      <p className="text-sm text-gray-600 mb-4">
        Upload a CSV file with columns: Serial Number, Name, Mobile Number, Loan Amount
      </p>
      <div className="space-y-4">
        <div className="flex items-center gap-4">
          <label className="flex-1">
            <div className="px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2 cursor-pointer">
              <Upload size={16} />
              <span>{file ? file.name : 'Choose CSV file'}</span>
            </div>
            <input
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              className="hidden"
            />
          </label>
          <Button
            variant="primary"
            onClick={handleImport}
            disabled={!file}
          >
            Import
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default BulkImportSheet;
