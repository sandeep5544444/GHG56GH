import React from 'react';
import { ChevronRight, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Member } from '../../types';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { formatCurrency } from '../../utils/calculations';
import { calculateMemberStats } from '../../utils/mockData';

interface MemberCardProps {
  member: Member;
}

const MemberCard: React.FC<MemberCardProps> = ({ member }) => {
  const { totalPaid, pendingAmount, lastPaidDate } = calculateMemberStats(member.id);
  
  return (
    <Card className="hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start">
        <div className="flex gap-4">
          {member.profilePicture && (
            <img 
              src={member.profilePicture} 
              alt={member.name}
              className="w-16 h-16 rounded-lg object-cover"
            />
          )}
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              {member.name || `#${member.serialNumber}`}
            </h3>
            {member.mobileNumber && (
              <div className="flex items-center text-gray-500 mt-1">
                <Phone size={14} className="mr-1" />
                <span>{member.mobileNumber}</span>
              </div>
            )}
          </div>
        </div>
        
        <Badge variant={pendingAmount > 0 ? 'warning' : 'success'}>
          {pendingAmount > 0 ? 'Pending' : 'Clear'}
        </Badge>
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-100">
        <div className="grid grid-cols-3 gap-4 text-sm">
          <div>
            <p className="text-gray-500">Daily Amount</p>
            <p className="font-medium">{formatCurrency(member.dailyAmount)}</p>
          </div>
          <div>
            <p className="text-gray-500">Total Paid</p>
            <p className="font-medium">{formatCurrency(totalPaid)}</p>
          </div>
          <div>
            <p className="text-gray-500">Last Paid</p>
            <p className="font-medium">{lastPaidDate === 'Never' ? 'Never' : new Date(lastPaidDate).toLocaleDateString()}</p>
          </div>
        </div>
      </div>
      
      <div className="mt-4">
        <Link 
          to={`/members/${member.id}`}
          className="flex items-center justify-end text-blue-600 hover:text-blue-800 font-medium text-sm"
        >
          <span>View Details</span>
          <ChevronRight size={16} />
        </Link>
      </div>
    </Card>
  );
};

export default MemberCard;