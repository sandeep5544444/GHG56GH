import React, { useState } from 'react';
import { Download, FileSpreadsheet, File as FilePdf } from 'lucide-react';
import { useApp } from '../context/AppContext';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import ReportFilters, { ReportFilters as FilterType } from '../components/reports/ReportFilters';
import PaymentList from '../components/payments/PaymentList';
import { formatCurrency } from '../utils/calculations';

const Reports: React.FC = () => {
  const { members, payments } = useApp();
  const [daysUnpaid, setDaysUnpaid] = useState(30);
  const [filters, setFilters] = useState<FilterType>({
    startDate: new Date(new Date().setDate(1)).toISOString().split('T')[0], // First day of current month
    endDate: new Date().toISOString().split('T')[0], // Today
    paymentStatus: 'all',
    memberId: '',
  });
  
  // Apply filters to payments
  const filteredPayments = payments.filter(payment => {
    // Date range filter
    const paymentDate = new Date(payment.date);
    const startDate = new Date(filters.startDate);
    const endDate = new Date(filters.endDate);
    
    if (paymentDate < startDate || paymentDate > endDate) {
      return false;
    }
    
    // Payment status filter
    if (filters.paymentStatus !== 'all' && payment.status !== filters.paymentStatus) {
      return false;
    }
    
    // Member filter
    if (filters.memberId && payment.memberId !== filters.memberId) {
      return false;
    }
    
    return true;
  });
  
  // Calculate totals
  const totalAmount = filteredPayments.reduce((sum, p) => sum + p.amount, 0);
  const paidAmount = filteredPayments
    .filter(p => p.status === 'paid')
    .reduce((sum, p) => sum + p.amount, 0);
  const unpaidAmount = filteredPayments
    .filter(p => p.status === 'not_paid')
    .reduce((sum, p) => sum + p.amount, 0);
  
  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
        <p className="text-gray-600">Generate and download payment reports</p>
      </div>
      
      <ReportFilters onFilterChange={setFilters} />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <h3 className="text-base font-medium text-gray-500 mb-1">Total Amount</h3>
          <p className="text-2xl font-semibold">{formatCurrency(totalAmount)}</p>
        </Card>
        
        <Card>
          <h3 className="text-base font-medium text-gray-500 mb-1">Paid Amount</h3>
          <p className="text-2xl font-semibold text-emerald-600">{formatCurrency(paidAmount)}</p>
        </Card>
        
        <Card>
          <h3 className="text-base font-medium text-gray-500 mb-1">Unpaid Amount</h3>
          <p className="text-2xl font-semibold text-amber-600">{formatCurrency(unpaidAmount)}</p>
        </Card>
      </div>
      
      <Card className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Payment Data</h2>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              className="flex items-center gap-1"
              onClick={() => {
                const data = filteredPayments.map(p => ({
                  date: p.date,
                  member: members.find(m => m.id === p.memberId)?.name,
                  amount: formatCurrency(p.amount),
                  status: p.status
                }));
                const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `payments-report-${new Date().toISOString().split('T')[0]}.json`;
                a.click();
                URL.revokeObjectURL(url);
              }}
            >
              <FilePdf size={16} />
              <span>Export PDF</span>
            </Button>
            <Button 
              variant="primary" 
              className="flex items-center gap-1"
              onClick={() => {
                const csvContent = [
                  ['Date', 'Member', 'Amount', 'Status'],
                  ...filteredPayments.map(p => [
                    p.date,
                    members.find(m => m.id === p.memberId)?.name,
                    formatCurrency(p.amount),
                    p.status
                  ])
                ].map(row => row.join(',')).join('\n');
                
                const blob = new Blob([csvContent], { type: 'text/csv' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `payments-report-${new Date().toISOString().split('T')[0]}.csv`;
                a.click();
                URL.revokeObjectURL(url);
              }}
            >
              <FileSpreadsheet size={16} />
              <span>Export Excel</span>
            </Button>
          </div>
        </div>
        
        <PaymentList payments={filteredPayments} members={members} />
      </Card>

      <Card className="mb-6">
        <div className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-3">Yesterday's Payment Status</h2>
          <div className="bg-gray-50 p-4 rounded-lg mb-4">
            <p className="text-gray-700">
              {payments.filter(p => {
                const yesterday = new Date();
                yesterday.setDate(yesterday.getDate() - 1);
                return p.date === yesterday.toISOString().split('T')[0] && p.status === 'paid';
              }).length} members paid yesterday
            </p>
            <div className="mt-4">
              <h3 className="font-medium text-red-600 mb-2">Members who didn't pay yesterday:</h3>
              <div className="space-y-2">
                {members.filter(member => {
                  const yesterday = new Date();
                  yesterday.setDate(yesterday.getDate() - 1);
                  const yesterdayStr = yesterday.toISOString().split('T')[0];
                  return !payments.some(p => 
                    p.memberId === member.id && 
                    p.date === yesterdayStr && 
                    p.status === 'paid'
                  );
                }).map(member => (
                  <div key={member.id} className="flex justify-between items-center p-2 bg-white rounded border">
                    <div>
                      <p className="font-medium">{member.name}</p>
                      <p className="text-sm text-gray-500">Serial: {member.serialNumber}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm">{member.mobileNumber}</p>
                      <p className="text-sm text-gray-500">Daily: {formatCurrency(member.dailyAmount)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Unpaid Members</h2>
          <select 
            value={daysUnpaid} 
            onChange={(e) => setDaysUnpaid(Number(e.target.value))}
            className="px-3 py-1 border rounded-lg"
          >
            <option value={7}>Last 7 days</option>
            <option value={30}>Last 30 days</option>
            <option value={90}>Last 90 days</option>
            <option value={365}>Last 365 days</option>
          </select>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-2">Serial Number</th>
                <th className="text-left py-2">Name</th>
                <th className="text-left py-2">Phone Number</th>
                <th className="text-left py-2">Last Paid</th>
              </tr>
            </thead>
            <tbody>
              {members.filter(member => {
                const memberPayments = payments.filter(p => p.memberId === member.id && p.status === 'paid');
                const lastPaid = memberPayments.length > 0 
                  ? new Date(Math.max(...memberPayments.map(p => new Date(p.date).getTime())))
                  : new Date(0);
                const daysSinceLastPayment = Math.floor((new Date().getTime() - lastPaid.getTime()) / (1000 * 3600 * 24));
                return daysSinceLastPayment >= daysUnpaid;
              }).map(member => (
                <tr key={member.id} className="border-b hover:bg-gray-50">
                  <td className="py-2">{member.serialNumber}</td>
                  <td className="py-2">{member.name}</td>
                  <td className="py-2">{member.mobileNumber}</td>
                  <td className="py-2">{
                    payments.filter(p => p.memberId === member.id && p.status === 'paid')
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0]?.date || 'Never'
                  }</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      
      <Card>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Saved Reports</h2>
        <div className="space-y-3">
          <div className="p-4 border border-gray-200 rounded-lg flex justify-between items-center">
            <div>
              <h3 className="font-medium">Monthly Collection - June 2025</h3>
              <p className="text-sm text-gray-500">Generated on June 30, 2025</p>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center gap-1"
            >
              <Download size={14} />
              <span>Download</span>
            </Button>
          </div>
          <div className="p-4 border border-gray-200 rounded-lg flex justify-between items-center">
            <div>
              <h3 className="font-medium">Pending Payments Report - Q2 2025</h3>
              <p className="text-sm text-gray-500">Generated on July 1, 2025</p>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center gap-1"
            >
              <Download size={14} />
              <span>Download</span>
            </Button>
          </div>
        </div>
      </Card>
    </Layout>
  );
};

export default Reports;