import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Edit, Trash, Upload, Check, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import Badge from '../components/ui/Badge';
import MemberForm from '../components/members/MemberForm';
import PaymentList from '../components/payments/PaymentList';
import { formatCurrency, formatDate } from '../utils/calculations';
import { calculateMemberStats } from '../utils/mockData';

const MemberDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { members, payments, updateMember, deleteMember } = useApp();
  
  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  
  const member = members.find(m => m.id === id);
  
  if (!member) {
    return (
      <Layout>
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Member Not Found</h2>
          <p className="text-gray-600 mb-6">The member you're looking for doesn't exist or has been removed.</p>
          <Button variant="primary" onClick={() => navigate('/members')}>
            Back to Members
          </Button>
        </div>
      </Layout>
    );
  }
  
  const memberPayments = payments.filter(p => p.memberId === id);
  const stats = calculateMemberStats(id);
  
  const handleUpdateMember = (data: any) => {
    updateMember(id!, data);
    setIsEditing(false);
  };
  
  const handleDeleteMember = () => {
    deleteMember(id!);
    navigate('/members');
  };
  
  return (
    <Layout>
      <div className="mb-6">
        <button 
          onClick={() => navigate('/members')} 
          className="flex items-center text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft size={16} className="mr-1" />
          <span>Back to Members</span>
        </button>
        
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{member.name}</h1>
            <p className="text-gray-600">Member #{member.serialNumber}</p>
          </div>
          
          {!isEditing && !showDeleteConfirm && (
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                className="flex items-center gap-1"
                onClick={() => setIsEditing(true)}
              >
                <Edit size={16} />
                <span>Edit</span>
              </Button>
              <Button 
                variant="danger" 
                className="flex items-center gap-1"
                onClick={() => setShowDeleteConfirm(true)}
              >
                <Trash size={16} />
                <span>Delete</span>
              </Button>
            </div>
          )}
        </div>
      </div>
      
      {showDeleteConfirm && (
        <Card className="mb-6 border border-red-200 bg-red-50">
          <h2 className="text-lg font-semibold text-red-700 mb-2">Confirm Deletion</h2>
          <p className="text-red-600 mb-4">
            Are you sure you want to delete this member? This will also delete all payment records and cannot be undone.
          </p>
          <div className="flex justify-end gap-2">
            <Button 
              variant="outline" 
              className="flex items-center gap-1"
              onClick={() => setShowDeleteConfirm(false)}
            >
              <X size={16} />
              <span>Cancel</span>
            </Button>
            <Button 
              variant="danger" 
              className="flex items-center gap-1"
              onClick={handleDeleteMember}
            >
              <Check size={16} />
              <span>Delete</span>
            </Button>
          </div>
        </Card>
      )}
      
      {isEditing ? (
        <Card className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Edit Member</h2>
          <MemberForm 
            initialData={member} 
            onSubmit={handleUpdateMember} 
            onCancel={() => setIsEditing(false)} 
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <Card className="lg:col-span-2">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Member Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Name</h3>
                <p className="mt-1">{member.name}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Mobile Number</h3>
                <p className="mt-1">{member.mobileNumber}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Serial Number</h3>
                <p className="mt-1">{member.serialNumber}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Daily Amount</h3>
                <p className="mt-1">{formatCurrency(member.dailyAmount)}</p>
              </div>
              <div className="md:col-span-2">
                <h3 className="text-sm font-medium text-gray-500">Notes</h3>
                <p className="mt-1">{member.notes || "No notes available"}</p>
              </div>
            </div>
          </Card>
          
          <Card>
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment Summary</h2>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Total Paid Till Now</h3>
                <p className="mt-1 text-xl font-semibold text-emerald-600">
                  {formatCurrency(stats.totalPaid)}
                </p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Pending Amount</h3>
                <p className={`mt-1 text-xl font-semibold ${
                  stats.pendingAmount > 0 ? 'text-amber-600' : 'text-emerald-600'
                }`}>
                  {formatCurrency(stats.pendingAmount)}
                </p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Last Paid Date</h3>
                <p className="mt-1">
                  {stats.lastPaidDate === 'Never' 
                    ? 'Never' 
                    : formatDate(stats.lastPaidDate)
                  }
                </p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500">Payment Status</h3>
                <Badge 
                  variant={stats.pendingAmount > 0 ? 'warning' : 'success'}
                  className="mt-1"
                >
                  {stats.pendingAmount > 0 ? 'Pending' : 'Cleared'}
                </Badge>
              </div>
            </div>
          </Card>
        </div>
      )}
      
      <div className="grid grid-cols-1 gap-6 mb-6">
        <Card>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Documents</h2>
            <Button variant="primary" size="sm" className="flex items-center gap-1">
              <Upload size={16} />
              <span>Upload</span>
            </Button>
          </div>
          
          {member.documents && member.documents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {member.documents.map(doc => (
                <div key={doc.id} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-medium">{doc.name}</h3>
                      <p className="text-sm text-gray-500">{doc.type}</p>
                    </div>
                    <Badge variant="info">{formatDate(doc.uploadDate)}</Badge>
                  </div>
                  <div className="flex gap-2 mt-2">
                    <Button variant="outline" size="sm">View</Button>
                    <Button variant="danger" size="sm">Delete</Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 border border-dashed border-gray-300 rounded-lg">
              <p className="text-gray-500">No documents uploaded yet</p>
              <p className="text-sm text-gray-400 mt-1">
                Upload Aadhaar, PAN, or any other documents
              </p>
            </div>
          )}
        </Card>
      </div>
      
      <Card>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment History</h2>
        {memberPayments.length > 0 ? (
          <PaymentList payments={memberPayments} members={members} />
        ) : (
          <div className="text-center py-8">
            <p className="text-gray-500">No payment records found</p>
          </div>
        )}
      </Card>
    </Layout>
  );
};

export default MemberDetails;