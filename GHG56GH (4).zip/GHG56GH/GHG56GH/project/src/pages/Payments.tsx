import React, { useState } from 'react';
import { PlusCircle, Filter } from 'lucide-react';
import { useApp } from '../context/AppContext';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import PaymentForm from '../components/payments/PaymentForm';
import PaymentList from '../components/payments/PaymentList';

const Payments: React.FC = () => {
  const { members, payments, addPayment, updatePayment, deletePayment } = useApp();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingPaymentId, setEditingPaymentId] = useState<string | null>(null);
  
  // Sort payments by date (most recent first)
  const sortedPayments = [...payments].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );
  
  const editingPayment = editingPaymentId 
    ? payments.find(p => p.id === editingPaymentId) 
    : null;
  
  const handleAddPayment = (data: any) => {
    addPayment(data);
    setShowAddForm(false);
  };
  
  const handleUpdatePayment = (data: any) => {
    if (editingPaymentId) {
      updatePayment(editingPaymentId, data);
      setEditingPaymentId(null);
    }
  };
  
  const handleDeletePayment = (id: string) => {
    if (confirm('Are you sure you want to delete this payment record?')) {
      deletePayment(id);
    }
  };
  
  return (
    <Layout>
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Payments</h1>
          <p className="text-gray-600">Manage daily payment records</p>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline"
            className="flex items-center gap-2"
          >
            <Filter size={18} />
            <span>Filter</span>
          </Button>
          <Button 
            variant="primary"
            className="flex items-center gap-2"
            onClick={() => {
              setEditingPaymentId(null);
              setShowAddForm(true);
            }}
          >
            <PlusCircle size={18} />
            <span>Record Payment</span>
          </Button>
        </div>
      </div>
      
      {(showAddForm || editingPaymentId) && (
        <Card className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">
            {editingPaymentId ? 'Edit Payment Record' : 'Record New Payment'}
          </h2>
          <PaymentForm 
            members={members}
            onSubmit={editingPaymentId ? handleUpdatePayment : handleAddPayment}
            onCancel={() => {
              setShowAddForm(false);
              setEditingPaymentId(null);
            }}
          />
        </Card>
      )}
      
      <Card>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment Records</h2>
        <PaymentList 
          payments={sortedPayments} 
          members={members}
          onEditPayment={setEditingPaymentId}
          onDeletePayment={handleDeletePayment}
        />
      </Card>
    </Layout>
  );
};

export default Payments;