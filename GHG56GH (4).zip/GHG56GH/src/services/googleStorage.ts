
import { Storage } from '@google-cloud/storage';
import { Firestore } from '@google-cloud/firestore';

const storage = new Storage({
  credentials: {
    client_email: process.env.GOOGLE_CLIENT_EMAIL,
    private_key: process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    project_id: process.env.GOOGLE_PROJECT_ID,
  },
});

const firestore = new Firestore({
  credentials: {
    client_email: process.env.GOOGLE_CLIENT_EMAIL,
    private_key: process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    project_id: process.env.GOOGLE_PROJECT_ID,
  },
});

export const GoogleStorageService = {
  async uploadFile(file: File, path: string) {
    const bucket = storage.bucket(process.env.GOOGLE_STORAGE_BUCKET || '');
    const blob = bucket.file(path);
    const blobStream = blob.createWriteStream();

    return new Promise((resolve, reject) => {
      blobStream.on('finish', () => {
        resolve(`https://storage.googleapis.com/${bucket.name}/${blob.name}`);
      });
      blobStream.on('error', reject);
      blobStream.end(file);
    });
  }
};

export const FirestoreService = {
  async saveMembers(members: any[]) {
    const batch = firestore.batch();
    members.forEach(member => {
      const docRef = firestore.collection('members').doc();
      batch.set(docRef, member);
    });
    await batch.commit();
  },

  async getMembers() {
    const snapshot = await firestore.collection('members').get();
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  }
};
