import {
  Home,
  Users,
  Calendar,
  BarChart,
  Settings,
  LogOut
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import LoginButton from '../auth/LoginButton';

// Assuming SidebarProps is defined elsewhere
export default function Sidebar({ onClose }: SidebarProps) {
  const { isLoggedIn, logout } = useAuth();

  return (
    <aside className="fixed h-screen w-64 bg-gray-100 shadow-md">
      <nav className="p-4">
        <ul>
          <li>
            <a href="#">
              <Home className="h-6 w-6 inline-block mr-2" /> Home
            </a>
          </li>
          <li>
            <a href="#">
              <Users className="h-6 w-6 inline-block mr-2" /> Users
            </a>
          </li>
          <li>
            <a href="#">
              <Calendar className="h-6 w-6 inline-block mr-2" /> Calendar
            </a>
          </li>
          <li>
            <a href="#">
              <BarChart className="h-6 w-6 inline-block mr-2" /> Analytics
            </a>
          </li>
          <li>
            <a href="#">
              <Settings className="h-6 w-6 inline-block mr-2" /> Settings
            </a>
          </li>
          {isLoggedIn ? (
            <li>
              <button onClick={logout}>
                <LogOut className="h-6 w-6 inline-block mr-2" /> Log Out
              </button>
            </li>
          ) : (
            <li>
              <LoginButton />
            </li>
          )}
        </ul>
      </nav>
    </aside>
  );
}