import React from 'react';
import { useAuth } from '../../context/AuthContext';
import Button from '../ui/Button';

export default function LoginButton() {
  const { isLoggedIn, login, logout, user } = useAuth();

  return isLoggedIn ? (
    <Button onClick={logout} variant="outline" className="w-full">
      Sign Out ({user?.email})
    </Button>
  ) : (
    <Button onClick={login} variant="primary" className="w-full">
      Sign in with GitHub
    </Button>
  );
}