import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./database-storage";
import { insertMemberSchema, insertPaymentSchema, insertDocumentSchema, memberFormSchema, paymentFormSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up API routes
  const apiRouter = app.route("/api");

  // Dashboard routes
  app.get("/api/dashboard", async (req: Request, res: Response) => {
    try {
      const date = req.query.date ? new Date(req.query.date as string) : new Date();
      const summary = await storage.getDashboardSummary(date);
      res.json(summary);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  // Member routes
  app.get("/api/members", async (req: Request, res: Response) => {
    try {
      const members = await storage.getAllMembers();
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch members" });
    }
  });

  app.get("/api/members/search", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const members = await storage.searchMembers(query);
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Failed to search members" });
    }
  });

  app.get("/api/members/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const member = await storage.getMember(id);
      
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      res.json(member);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch member details" });
    }
  });

  app.get("/api/members/serial/:serialNumber", async (req: Request, res: Response) => {
    try {
      const serialNumber = req.params.serialNumber;
      const member = await storage.getMemberBySerialNumber(serialNumber);
      
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      res.json(member);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch member details" });
    }
  });

  app.post("/api/members", async (req: Request, res: Response) => {
    try {
      const memberData = memberFormSchema.parse(req.body);
      const member = await storage.createMember(memberData);
      res.status(201).json(member);
    } catch (error) {
      console.error("Member creation error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid member data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create member" });
    }
  });

  app.put("/api/members/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const memberData = memberFormSchema.partial().parse(req.body);
      
      const member = await storage.updateMember(id, memberData);
      
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      res.json(member);
    } catch (error) {
      console.error("Member update error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid member data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update member" });
    }
  });

  app.delete("/api/members/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteMember(id);
      
      if (!success) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete member" });
    }
  });

  // Payment routes
  app.get("/api/payments", async (req: Request, res: Response) => {
    try {
      const payments = await storage.getAllPayments();
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch payments" });
    }
  });

  app.get("/api/payments/member/:memberId", async (req: Request, res: Response) => {
    try {
      const memberId = parseInt(req.params.memberId);
      const payments = await storage.getPaymentsByMemberId(memberId);
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch member payments" });
    }
  });

  app.get("/api/payments/date/:date", async (req: Request, res: Response) => {
    try {
      const date = new Date(req.params.date);
      const payments = await storage.getPaymentsByDate(date);
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch payments by date" });
    }
  });

  app.post("/api/payments", async (req: Request, res: Response) => {
    try {
      const paymentData = paymentFormSchema.parse(req.body);
      
      // Verify member exists
      const member = await storage.getMember(paymentData.memberId);
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      const payment = await storage.createPayment(paymentData);
      res.status(201).json(payment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid payment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create payment" });
    }
  });

  app.put("/api/payments/:id/status", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { isPaid } = req.body;
      
      if (typeof isPaid !== 'boolean') {
        return res.status(400).json({ message: "isPaid status must be a boolean" });
      }
      
      const payment = await storage.updatePaymentStatus(id, isPaid);
      
      if (!payment) {
        return res.status(404).json({ message: "Payment not found" });
      }
      
      res.json(payment);
    } catch (error) {
      res.status(500).json({ message: "Failed to update payment status" });
    }
  });

  // Document routes
  app.get("/api/documents/member/:memberId", async (req: Request, res: Response) => {
    try {
      const memberId = parseInt(req.params.memberId);
      const documents = await storage.getDocumentsByMemberId(memberId);
      res.json(documents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch member documents" });
    }
  });

  app.post("/api/documents", async (req: Request, res: Response) => {
    try {
      const documentData = insertDocumentSchema.parse(req.body);
      
      // Verify member exists
      const member = await storage.getMember(documentData.memberId);
      if (!member) {
        return res.status(404).json({ message: "Member not found" });
      }
      
      const document = await storage.createDocument(documentData);
      res.status(201).json(document);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid document data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create document" });
    }
  });

  app.delete("/api/documents/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteDocument(id);
      
      if (!success) {
        return res.status(404).json({ message: "Document not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete document" });
    }
  });

  // Settings routes
  app.get("/api/settings/:key", async (req: Request, res: Response) => {
    try {
      const key = req.params.key;
      const setting = await storage.getSetting(key);
      
      if (!setting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      
      res.json({ key: setting.key, value: setting.value });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch setting" });
    }
  });

  app.put("/api/settings/:key", async (req: Request, res: Response) => {
    try {
      const key = req.params.key;
      const { value } = req.body;
      
      if (typeof value !== 'string') {
        return res.status(400).json({ message: "Setting value must be a string" });
      }
      
      const setting = await storage.updateSetting(key, value);
      res.json({ key: setting.key, value: setting.value });
    } catch (error) {
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  // Backup routes
  app.get("/api/backups", async (req: Request, res: Response) => {
    try {
      const backups = await storage.getAllBackups();
      res.json(backups);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch backups" });
    }
  });

  app.post("/api/backups/create", async (req: Request, res: Response) => {
    try {
      // In a real app, we would generate a backup file here
      // For this prototype, we'll just create a record
      const backup = await storage.createBackup({
        path: `/backups/backup-${Date.now()}.json`,
        size: Math.floor(Math.random() * 1000000) // Random size for demo
      });
      
      res.status(201).json(backup);
    } catch (error) {
      res.status(500).json({ message: "Failed to create backup" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
