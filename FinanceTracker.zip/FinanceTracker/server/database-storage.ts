import { 
  users, members, payments, documents, backups, settings,
  type User, type Member, type Payment, type Document, type Backup, type Setting,
  type InsertUser, type InsertMember, type InsertPayment, type InsertDocument, type InsertBackup, type InsertSetting
} from "@shared/schema";
import { db } from "./db";
import { eq, like, desc, gte, lte, sql, or, and } from "drizzle-orm";
import { DashboardSummary, IStorage } from "./storage";
import { format, startOfDay, endOfDay, subDays, addDays } from 'date-fns';

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Member methods
  async getAllMembers(): Promise<Member[]> {
    return await db.select().from(members).orderBy(members.name);
  }

  async getMember(id: number): Promise<Member | undefined> {
    const [member] = await db.select().from(members).where(eq(members.id, id));
    return member || undefined;
  }

  async getMemberBySerialNumber(serialNumber: string): Promise<Member | undefined> {
    const [member] = await db.select().from(members).where(eq(members.serialNumber, serialNumber));
    return member || undefined;
  }

  async createMember(insertMember: InsertMember): Promise<Member> {
    const [member] = await db
      .insert(members)
      .values({
        ...insertMember,
        totalPaid: 0,
        pending: insertMember.loanAmount,
      })
      .returning();
    return member;
  }

  async updateMember(id: number, updates: Partial<InsertMember>): Promise<Member | undefined> {
    const [updatedMember] = await db
      .update(members)
      .set(updates)
      .where(eq(members.id, id))
      .returning();
    return updatedMember || undefined;
  }

  async deleteMember(id: number): Promise<boolean> {
    const [deletedMember] = await db
      .delete(members)
      .where(eq(members.id, id))
      .returning();
    return !!deletedMember;
  }

  async searchMembers(query: string): Promise<Member[]> {
    const searchPattern = `%${query}%`;
    return await db
      .select()
      .from(members)
      .where(
        or(
          like(members.name, searchPattern),
          like(members.serialNumber, searchPattern),
          like(members.mobileNumber, searchPattern),
          like(members.address || '', searchPattern)
        )
      )
      .orderBy(members.name);
  }

  // Payment methods
  async getAllPayments(): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .orderBy(desc(payments.paymentDate));
  }

  async getPaymentsByMemberId(memberId: number): Promise<Payment[]> {
    return await db
      .select()
      .from(payments)
      .where(eq(payments.memberId, memberId))
      .orderBy(desc(payments.paymentDate));
  }

  async getPaymentsByDate(date: Date): Promise<Payment[]> {
    const startDate = startOfDay(date);
    const endDate = endOfDay(date);
    return await db
      .select()
      .from(payments)
      .where(
        and(
          gte(payments.paymentDate, startDate),
          lte(payments.paymentDate, endDate)
        )
      )
      .orderBy(desc(payments.paymentDate));
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const [payment] = await db
      .insert(payments)
      .values(insertPayment)
      .returning();

    // Update member's total paid and last paid date
    if (payment.isPaid) {
      const member = await this.getMember(payment.memberId);
      if (member) {
        const totalPaid = (member.totalPaid || 0) + payment.amount + (payment.advanceAmount || 0);
        const pending = member.loanAmount - totalPaid;

        await db
          .update(members)
          .set({
            totalPaid,
            pending,
            lastPaidDate: payment.paymentDate
          })
          .where(eq(members.id, payment.memberId));
      }
    }

    return payment;
  }

  async updatePaymentStatus(id: number, isPaid: boolean): Promise<Payment | undefined> {
    const [payment] = await db
      .select()
      .from(payments)
      .where(eq(payments.id, id));

    if (!payment) return undefined;

    const [updatedPayment] = await db
      .update(payments)
      .set({ isPaid })
      .where(eq(payments.id, id))
      .returning();

    // Update member's total paid and last paid date if payment is marked as paid
    if (isPaid && !payment.isPaid) {
      const member = await this.getMember(payment.memberId);
      if (member) {
        const totalAmount = Number(payment.amount || 0) + Number(payment.advanceAmount || 0);
        const totalPaid = Number(member.totalPaid || 0) + totalAmount;
        const pending = Number(member.loanAmount || 0) - totalPaid;

        await db
          .update(members)
          .set({
            totalPaid: Math.round(totalPaid * 100) / 100,
            pending: Math.round(pending * 100) / 100,
            lastPaidDate: payment.paymentDate
          })
          .where(eq(members.id, payment.memberId));
      }
    } 
    // If payment is marked as unpaid, subtract from total paid
    else if (!isPaid && payment.isPaid) {
      const member = await this.getMember(payment.memberId);
      if (member) {
        const totalAmount = Number(payment.amount || 0) + Number(payment.advanceAmount || 0);
        const totalPaid = Math.max(0, Number(member.totalPaid || 0) - totalAmount);
        const pending = Number(member.loanAmount || 0) - totalPaid;

        await db
          .update(members)
          .set({
            totalPaid,
            pending
          })
          .where(eq(members.id, payment.memberId));
      }
    }

    return updatedPayment || undefined;
  }

  // Document methods
  async getDocumentsByMemberId(memberId: number): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(eq(documents.memberId, memberId))
      .orderBy(desc(documents.uploadedAt));
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const [document] = await db
      .insert(documents)
      .values(insertDocument)
      .returning();
    return document;
  }

  async deleteDocument(id: number): Promise<boolean> {
    const [deletedDocument] = await db
      .delete(documents)
      .where(eq(documents.id, id))
      .returning();
    return !!deletedDocument;
  }

  // Backup methods
  async getAllBackups(): Promise<Backup[]> {
    return await db
      .select()
      .from(backups)
      .orderBy(desc(backups.createdAt));
  }

  async createBackup(insertBackup: InsertBackup): Promise<Backup> {
    const [backup] = await db
      .insert(backups)
      .values(insertBackup)
      .returning();
    return backup;
  }

  // Settings methods
  async getSetting(key: string): Promise<Setting | undefined> {
    const [setting] = await db
      .select()
      .from(settings)
      .where(eq(settings.key, key));
    return setting || undefined;
  }

  async updateSetting(key: string, value: string): Promise<Setting> {
    // Check if setting exists
    const existingSetting = await this.getSetting(key);

    if (existingSetting) {
      // Update existing setting
      const [updatedSetting] = await db
        .update(settings)
        .set({ value, updatedAt: new Date() })
        .where(eq(settings.key, key))
        .returning();
      return updatedSetting;
    } else {
      // Create new setting
      const [newSetting] = await db
        .insert(settings)
        .values({ key, value })
        .returning();
      return newSetting;
    }
  }

  // Dashboard methods
  async getDashboardSummary(date: Date = new Date()): Promise<DashboardSummary> {
    // Get today's payments
    const todayStart = startOfDay(date);
    const todayEnd = endOfDay(date);

    const todayPayments = await db
      .select()
      .from(payments)
      .where(
        and(
          gte(payments.paymentDate, todayStart),
          lte(payments.paymentDate, todayEnd)
        )
      );

    // Calculate today's collection
    const paidPayments = todayPayments.filter(p => p.isPaid);
    const paidAmount = 0; // Reset today's collection amount

    // Get all active members
    const allMembers = await db
      .select()
      .from(members);

    const activeMembers = allMembers.filter(m => m.isActive);

    // Find members who haven't paid today
    const paidMemberIds = new Set(paidPayments.map(p => p.memberId));
    const unpaidMembers = activeMembers.filter(m => !paidMemberIds.has(m.id));
    const unpaidAmount = unpaidMembers.reduce((sum, m) => sum + m.dailyAmount, 0);

    // Calculate monthly collection
    const thisMonth = date.getMonth();
    const thisYear = date.getFullYear();

    const monthStart = new Date(thisYear, thisMonth, 1);
    const monthEnd = new Date(thisYear, thisMonth + 1, 0, 23, 59, 59, 999);

    const monthlyPayments = await db
      .select()
      .from(payments)
      .where(
        and(
          gte(payments.paymentDate, monthStart),
          lte(payments.paymentDate, monthEnd),
          eq(payments.isPaid, true)
        )
      );

    const monthlyTotal = 0; // Reset monthly collection

    // Monthly target is active members * daily amount * days in month
    const daysInMonth = new Date(thisYear, thisMonth + 1, 0).getDate();
    const monthlyTarget = activeMembers.reduce((sum, m) => sum + (m.dailyAmount * daysInMonth), 0);

    // Loan summary
    const loanSummary = {
      totalDistributed: allMembers.reduce((sum, m) => sum + m.loanAmount, 0),
      activeMembers: activeMembers.length
    };

    // Outstanding summary
    const totalPending = allMembers.reduce((sum, m) => sum + (m.pending || 0), 0);
    const totalLoan = loanSummary.totalDistributed;

    const outstandingSummary = {
      pendingAmount: totalPending,
      pendingPercentage: totalLoan > 0 ? Math.round((totalPending / totalLoan) * 100) : 0
    };

    // Recent payments
    const recentPayments = await db
      .select()
      .from(payments)
      .orderBy(desc(payments.paymentDate))
      .limit(5);

    // Alerts
    const sevenDaysAgo = subDays(todayStart, 7);
    const tomorrow = addDays(todayStart, 1);
    const weekEnd = addDays(todayStart, 7);

    // Members with no payment in last 7 days
    const membersWithRecentPayments = await db
      .select({ memberId: payments.memberId })
      .from(payments)
      .where(
        and(
          gte(payments.paymentDate, sevenDaysAgo),
          eq(payments.isPaid, true)
        )
      )
      .groupBy(payments.memberId);

    const recentPaymentMemberIds = new Set(membersWithRecentPayments.map(r => r.memberId));
    const noPayment7Days = activeMembers.filter(m => !recentPaymentMemberIds.has(m.id)).length;

    // Calculate members with payments due tomorrow
    const dueForTomorrow = activeMembers.length; // Simplified - in real app would check schedules

    // Members completing this week
    const completingThisWeek = activeMembers.filter(m => {
      if (!m.endDate) return false;
      return new Date(m.endDate) <= weekEnd;
    }).length;

    const alerts = {
      noPayment7Days,
      dueForTomorrow,
      completingThisWeek
    };

    return {
      todayCollection: {
        paidCount: paidPayments.length,
        paidAmount,
        unpaidCount: unpaidMembers.length,
        unpaidAmount
      },
      monthlyCollection: {
        totalAmount: monthlyTotal,
        target: monthlyTarget,
        percentage: monthlyTarget > 0 ? Math.round((monthlyTotal / monthlyTarget) * 100) : 0
      },
      loanSummary,
      outstandingSummary,
      recentPayments,
      alerts
    };
  }
}

// Initialize sample settings if needed
export async function initializeDatabase() {
  // Check if we have any users
  const [userCount] = await db.select({ count: sql`count(*)` }).from(users);

  // If no users, create admin user
  if (!userCount || Number(userCount.count) === 0) {
    await db.insert(users).values({
      username: 'admin',
      password: 'admin123', // In a real app, this would be hashed
      name: 'Administrator',
      email: 'admin@example.com',
      role: 'admin'
    });
  }

  // Check if we have any settings
  const [settingsCount] = await db.select({ count: sql`count(*)` }).from(settings);

  // If no settings, add default settings
  if (!settingsCount || Number(settingsCount.count) === 0) {
    await db.insert(settings).values([
      { key: 'companyName', value: 'Daily Finance' },
      { key: 'currency', value: 'INR' },
      { key: 'backupFrequency', value: 'weekly' }
    ]);
  }

  // Check if we have members
  const [memberCount] = await db.select({ count: sql`count(*)` }).from(members);

  // If no members, add sample members for demo
  if (!memberCount || Number(memberCount.count) === 0) {
    await db.insert(members).values([
      {
        serialNumber: "DL-1043",
        name: "Rahul Kumar",
        mobileNumber: "9876543210",
        address: "123 Main St, Delhi",
        loanAmount: 15000,
        dailyAmount: 500,
        totalPaid: 5000,
        pending: 10000,
        startDate: new Date(2023, 4, 1), // May 1, 2023
        endDate: new Date(2023, 10, 1), // Nov 1, 2023
        isActive: true
      },
      {
        serialNumber: "DL-0872",
        name: "Sunita Patel",
        mobileNumber: "8765432109",
        address: "456 Park Ave, Mumbai",
        loanAmount: 20000,
        dailyAmount: 500,
        totalPaid: 7000,
        pending: 13000,
        startDate: new Date(2023, 3, 15), // Apr 15, 2023
        endDate: new Date(2023, 11, 15), // Dec 15, 2023
        isActive: true
      },
      {
        serialNumber: "DL-1356",
        name: "Anil Mehta",
        mobileNumber: "7654321098",
        address: "789 Ring Road, Bangalore",
        loanAmount: 10000,
        dailyAmount: 500,
        totalPaid: 3000,
        pending: 7000,
        startDate: new Date(2023, 5, 10), // Jun 10, 2023
        endDate: new Date(2023, 9, 10), // Oct 10, 2023
        isActive: true
      }
    ]);

    // Add some sample payments
    const today = new Date();

    await db.insert(payments).values([
      {
        memberId: 1,
        amount: 500,
        advanceAmount: 0,
        paymentDate: today,
        notes: "Regular payment",
        isPaid: true
      },
      {
        memberId: 2,
        amount: 500,
        advanceAmount: 500,
        paymentDate: today,
        notes: "Paid with advance",
        isPaid: true
      },
      {
        memberId: 3,
        amount: 500,
        paymentDate: today,
        notes: "Regular collection",
        isPaid: true
      }
    ]);
  }
}

// Create a singleton instance of DatabaseStorage
export const storage = new DatabaseStorage();