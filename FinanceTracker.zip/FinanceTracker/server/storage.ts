import { 
  users, type User, type InsertUser,
  members, type Member, type InsertMember,
  payments, type Payment, type InsertPayment,
  documents, type Document, type InsertDocument,
  backups, type Backup, type InsertBackup,
  settings, type Setting, type InsertSetting
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Member methods
  getAllMembers(): Promise<Member[]>;
  getMember(id: number): Promise<Member | undefined>;
  getMemberBySerialNumber(serialNumber: string): Promise<Member | undefined>;
  createMember(member: InsertMember): Promise<Member>;
  updateMember(id: number, updates: Partial<InsertMember>): Promise<Member | undefined>;
  deleteMember(id: number): Promise<boolean>;
  searchMembers(query: string): Promise<Member[]>;

  // Payment methods
  getAllPayments(): Promise<Payment[]>;
  getPaymentsByMemberId(memberId: number): Promise<Payment[]>;
  getPaymentsByDate(date: Date): Promise<Payment[]>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePaymentStatus(id: number, isPaid: boolean): Promise<Payment | undefined>;

  // Document methods
  getDocumentsByMemberId(memberId: number): Promise<Document[]>;
  createDocument(document: InsertDocument): Promise<Document>;
  deleteDocument(id: number): Promise<boolean>;

  // Backup methods
  getAllBackups(): Promise<Backup[]>;
  createBackup(backup: InsertBackup): Promise<Backup>;

  // Settings methods
  getSetting(key: string): Promise<Setting | undefined>;
  updateSetting(key: string, value: string): Promise<Setting>;

  // Dashboard methods
  getDashboardSummary(date?: Date): Promise<DashboardSummary>;
}

export interface DashboardSummary {
  todayCollection: {
    paidCount: number;
    paidAmount: number;
    unpaidCount: number;
    unpaidAmount: number;
  };
  monthlyCollection: {
    totalAmount: number;
    target: number;
    percentage: number;
  };
  loanSummary: {
    totalDistributed: number;
    activeMembers: number;
  };
  outstandingSummary: {
    pendingAmount: number;
    pendingPercentage: number;
  };
  recentPayments: Payment[];
  alerts: {
    noPayment7Days: number;
    dueForTomorrow: number;
    completingThisWeek: number;
  };
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private members: Map<number, Member>;
  private payments: Map<number, Payment>;
  private documents: Map<number, Document>;
  private backups: Map<number, Backup>;
  private settings: Map<number, Setting>;
  
  private currentUserId: number;
  private currentMemberId: number;
  private currentPaymentId: number;
  private currentDocumentId: number;
  private currentBackupId: number;
  private currentSettingId: number;

  constructor() {
    this.users = new Map();
    this.members = new Map();
    this.payments = new Map();
    this.documents = new Map();
    this.backups = new Map();
    this.settings = new Map();
    
    this.currentUserId = 1;
    this.currentMemberId = 1;
    this.currentPaymentId = 1;
    this.currentDocumentId = 1;
    this.currentBackupId = 1;
    this.currentSettingId = 1;
    
    // Add some sample data for development
    this.initSampleData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Member methods
  async getAllMembers(): Promise<Member[]> {
    return Array.from(this.members.values());
  }

  async getMember(id: number): Promise<Member | undefined> {
    return this.members.get(id);
  }

  async getMemberBySerialNumber(serialNumber: string): Promise<Member | undefined> {
    return Array.from(this.members.values()).find(
      (member) => member.serialNumber === serialNumber,
    );
  }

  async createMember(insertMember: InsertMember): Promise<Member> {
    const id = this.currentMemberId++;
    const member: Member = { 
      ...insertMember, 
      id, 
      totalPaid: 0,
      pending: insertMember.loanAmount,
      createdAt: new Date() 
    };
    this.members.set(id, member);
    return member;
  }

  async updateMember(id: number, updates: Partial<InsertMember>): Promise<Member | undefined> {
    const member = this.members.get(id);
    if (!member) return undefined;
    
    const updatedMember = { ...member, ...updates };
    this.members.set(id, updatedMember);
    return updatedMember;
  }

  async deleteMember(id: number): Promise<boolean> {
    return this.members.delete(id);
  }

  async searchMembers(query: string): Promise<Member[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.members.values()).filter(
      (member) => 
        member.name.toLowerCase().includes(lowercaseQuery) ||
        member.mobileNumber.includes(query) ||
        member.serialNumber.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Payment methods
  async getAllPayments(): Promise<Payment[]> {
    return Array.from(this.payments.values());
  }

  async getPaymentsByMemberId(memberId: number): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(
      (payment) => payment.memberId === memberId
    );
  }

  async getPaymentsByDate(date: Date): Promise<Payment[]> {
    const targetDate = new Date(date);
    targetDate.setHours(0, 0, 0, 0);
    
    return Array.from(this.payments.values()).filter(payment => {
      const paymentDate = new Date(payment.paymentDate);
      paymentDate.setHours(0, 0, 0, 0);
      return paymentDate.getTime() === targetDate.getTime();
    });
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = this.currentPaymentId++;
    const payment: Payment = { 
      ...insertPayment, 
      id, 
      createdAt: new Date()
    };
    this.payments.set(id, payment);
    
    // Update member's totalPaid, pending, and lastPaidDate
    const member = this.members.get(payment.memberId);
    if (member && payment.isPaid) {
      const totalAmount = payment.amount + (payment.advanceAmount || 0);
      const updatedMember = { 
        ...member, 
        totalPaid: member.totalPaid + totalAmount,
        pending: member.loanAmount - (member.totalPaid + totalAmount),
        lastPaidDate: payment.paymentDate
      };
      this.members.set(member.id, updatedMember);
    }
    
    return payment;
  }

  async updatePaymentStatus(id: number, isPaid: boolean): Promise<Payment | undefined> {
    const payment = this.payments.get(id);
    if (!payment) return undefined;
    
    const updatedPayment = { ...payment, isPaid };
    this.payments.set(id, updatedPayment);
    
    // Update member's totalPaid and pending if status changed
    if (payment.isPaid !== isPaid) {
      const member = this.members.get(payment.memberId);
      if (member) {
        const totalAmount = payment.amount + (payment.advanceAmount || 0);
        const updatedMember = { 
          ...member, 
          totalPaid: isPaid 
            ? member.totalPaid + totalAmount 
            : member.totalPaid - totalAmount,
          pending: isPaid
            ? member.pending - totalAmount
            : member.pending + totalAmount
        };
        this.members.set(member.id, updatedMember);
      }
    }
    
    return updatedPayment;
  }

  // Document methods
  async getDocumentsByMemberId(memberId: number): Promise<Document[]> {
    return Array.from(this.documents.values()).filter(
      (document) => document.memberId === memberId
    );
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = this.currentDocumentId++;
    const document: Document = { 
      ...insertDocument, 
      id, 
      uploadedAt: new Date()
    };
    this.documents.set(id, document);
    return document;
  }

  async deleteDocument(id: number): Promise<boolean> {
    return this.documents.delete(id);
  }

  // Backup methods
  async getAllBackups(): Promise<Backup[]> {
    return Array.from(this.backups.values());
  }

  async createBackup(insertBackup: InsertBackup): Promise<Backup> {
    const id = this.currentBackupId++;
    const backup: Backup = { 
      ...insertBackup, 
      id, 
      createdAt: new Date()
    };
    this.backups.set(id, backup);
    return backup;
  }

  // Settings methods
  async getSetting(key: string): Promise<Setting | undefined> {
    return Array.from(this.settings.values()).find(
      (setting) => setting.key === key
    );
  }

  async updateSetting(key: string, value: string): Promise<Setting> {
    const existingSetting = await this.getSetting(key);
    
    if (existingSetting) {
      const updatedSetting = { 
        ...existingSetting, 
        value, 
        updatedAt: new Date()
      };
      this.settings.set(existingSetting.id, updatedSetting);
      return updatedSetting;
    } else {
      const id = this.currentSettingId++;
      const setting: Setting = { 
        id, 
        key, 
        value, 
        updatedAt: new Date()
      };
      this.settings.set(id, setting);
      return setting;
    }
  }

  // Dashboard methods
  async getDashboardSummary(date?: Date): Promise<DashboardSummary> {
    const targetDate = date || new Date();
    targetDate.setHours(0, 0, 0, 0);
    
    const allMembers = await this.getAllMembers();
    const activeMembers = allMembers.filter(member => member.isActive);
    
    // Get today's payments
    const todayPayments = await this.getPaymentsByDate(targetDate);
    const paidPayments = todayPayments.filter(payment => payment.isPaid);
    const unpaidMembers = activeMembers.filter(member => 
      !todayPayments.some(payment => 
        payment.memberId === member.id && payment.isPaid
      )
    );
    
    // Calculate today's summary
    const paidAmount = paidPayments.reduce((sum, payment) => 
      sum + payment.amount + (payment.advanceAmount || 0), 0);
    const unpaidAmount = unpaidMembers.reduce((sum, member) => 
      sum + member.dailyAmount, 0);
    
    // Calculate monthly collection
    const now = new Date();
    const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    
    const monthlyPayments = Array.from(this.payments.values()).filter(payment => {
      const paymentDate = new Date(payment.paymentDate);
      return payment.isPaid && 
             paymentDate >= firstDayOfMonth && 
             paymentDate <= lastDayOfMonth;
    });
    
    const monthlyTotal = monthlyPayments.reduce((sum, payment) => 
      sum + payment.amount + (payment.advanceAmount || 0), 0);
    
    // Calculate monthly target (daily amount * active members * business days in month)
    // For simplicity, assuming 22 business days per month
    const businessDaysInMonth = 22;
    const monthlyTarget = activeMembers.reduce((sum, member) => 
      sum + (member.dailyAmount * businessDaysInMonth), 0);
    
    // Calculate loan summary
    const totalLoanDistributed = allMembers.reduce((sum, member) => 
      sum + member.loanAmount, 0);
    
    // Calculate outstanding summary
    const totalPending = activeMembers.reduce((sum, member) => 
      sum + member.pending, 0);
    const pendingPercentage = Math.round((totalPending / totalLoanDistributed) * 100);
    
    // Calculate alerts
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    const weekFromNow = new Date();
    weekFromNow.setDate(weekFromNow.getDate() + 7);
    
    const noPayment7Days = activeMembers.filter(member => {
      if (!member.lastPaidDate) return true;
      const lastPaid = new Date(member.lastPaidDate);
      return lastPaid < sevenDaysAgo;
    }).length;
    
    const dueForTomorrow = activeMembers.length - todayPayments.filter(p => p.isPaid).length;
    
    const completingThisWeek = activeMembers.filter(member => {
      if (!member.endDate) return false;
      const endDate = new Date(member.endDate);
      return endDate <= weekFromNow;
    }).length;
    
    // Get recent payments for the table
    const recentPayments = Array.from(this.payments.values())
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5);
    
    return {
      todayCollection: {
        paidCount: paidPayments.length,
        paidAmount,
        unpaidCount: unpaidMembers.length,
        unpaidAmount
      },
      monthlyCollection: {
        totalAmount: monthlyTotal,
        target: monthlyTarget,
        percentage: monthlyTarget > 0 ? Math.round((monthlyTotal / monthlyTarget) * 100) : 0
      },
      loanSummary: {
        totalDistributed: totalLoanDistributed,
        activeMembers: activeMembers.length
      },
      outstandingSummary: {
        pendingAmount: totalPending,
        pendingPercentage
      },
      recentPayments,
      alerts: {
        noPayment7Days,
        dueForTomorrow,
        completingThisWeek
      }
    };
  }

  private initSampleData() {
    // Create admin user
    this.createUser({
      username: "admin",
      password: "password",
      name: "Admin User",
      email: "admin@example.com",
      role: "admin"
    });

    // Create some sample members
    const members = [
      {
        serialNumber: "DL-1043",
        name: "Rahul Kumar",
        mobileNumber: "9876543210",
        address: "123 Main St, Delhi",
        loanAmount: 15000,
        dailyAmount: 500,
        startDate: new Date(2023, 4, 1), // May 1, 2023
        endDate: new Date(2023, 10, 1), // Nov 1, 2023
        isActive: true
      },
      {
        serialNumber: "DL-0872",
        name: "Sunita Patel",
        mobileNumber: "8765432109",
        address: "456 Park Ave, Mumbai",
        loanAmount: 20000,
        dailyAmount: 500,
        startDate: new Date(2023, 3, 15), // Apr 15, 2023
        endDate: new Date(2023, 11, 15), // Dec 15, 2023
        isActive: true
      },
      {
        serialNumber: "DL-1356",
        name: "Anil Mehta",
        mobileNumber: "7654321098",
        address: "789 Ring Road, Bangalore",
        loanAmount: 10000,
        dailyAmount: 500,
        startDate: new Date(2023, 5, 10), // Jun 10, 2023
        endDate: new Date(2023, 9, 10), // Oct 10, 2023
        isActive: true
      },
      {
        serialNumber: "DL-0945",
        name: "Neha Sharma",
        mobileNumber: "6543210987",
        address: "321 Lake View, Chennai",
        loanAmount: 15000,
        dailyAmount: 700,
        startDate: new Date(2023, 2, 20), // Mar 20, 2023
        endDate: new Date(2023, 8, 20), // Sep 20, 2023
        isActive: true
      },
      {
        serialNumber: "DL-0578",
        name: "Vijay Gupta",
        mobileNumber: "5432109876",
        address: "567 Hill Road, Hyderabad",
        loanAmount: 8000,
        dailyAmount: 300,
        startDate: new Date(2023, 6, 5), // Jul 5, 2023
        endDate: new Date(2023, 10, 5), // Nov 5, 2023
        isActive: true
      }
    ];

    // Create sample members
    members.forEach(async member => {
      await this.createMember(member);
    });

    // Create some sample payments
    const today = new Date();
    
    this.createPayment({
      memberId: 1,
      amount: 500,
      advanceAmount: 0,
      paymentDate: today,
      notes: "Regular payment",
      isPaid: true
    });

    this.createPayment({
      memberId: 2,
      amount: 500,
      advanceAmount: 500,
      paymentDate: today,
      notes: "Paid with advance",
      isPaid: true
    });

    this.createPayment({
      memberId: 5,
      amount: 300,
      advanceAmount: 0,
      paymentDate: today,
      notes: "Regular payment",
      isPaid: true
    });

    // Create some sample settings
    this.updateSetting("backup_frequency", "weekly");
    this.updateSetting("backup_day", "sunday");
    this.updateSetting("backup_time", "00:00");
    this.updateSetting("sms_reminders", "enabled");
  }
}

export const storage = new MemStorage();
