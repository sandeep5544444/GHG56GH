import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Setting } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  User,
  Shield,
  Database,
  Bell,
  Smartphone,
  FileText,
  Save,
  AlertTriangle 
} from "lucide-react";

interface AppSetting {
  key: string;
  value: string;
}

export default function Settings() {
  const [activeTab, setActiveTab] = useState("account");
  const [backupConfirmOpen, setBackupConfirmOpen] = useState(false);
  const [restoreDialogOpen, setRestoreDialogOpen] = useState(false);
  const { toast } = useToast();

  // Get application settings
  const { data: backupSettings, isLoading: backupSettingsLoading } = useQuery<AppSetting>({
    queryKey: ['/api/settings/backup_frequency'],
  });

  const { data: smsSettings, isLoading: smsSettingsLoading } = useQuery<AppSetting>({
    queryKey: ['/api/settings/sms_reminders'],
  });

  // Update setting mutation
  const updateSettingMutation = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: string }) => {
      const response = await apiRequest('PUT', `/api/settings/${key}`, { value });
      return response.json();
    },
    onSuccess: (_, variables) => {
      toast({
        title: "Settings Updated",
        description: "Your settings have been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/settings/${variables.key}`] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Create backup mutation
  const createBackupMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/backups/create', {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Backup Created",
        description: "Your data has been backed up successfully.",
      });
      setBackupConfirmOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create backup. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleUpdateSetting = (key: string, value: string) => {
    updateSettingMutation.mutate({ key, value });
  };

  const handleBackupNow = () => {
    setBackupConfirmOpen(true);
  };

  const confirmBackup = () => {
    createBackupMutation.mutate();
  };

  const handleRestore = () => {
    setRestoreDialogOpen(false);
    toast({
      title: "Restore Complete",
      description: "Your data has been restored successfully.",
    });
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-2 md:grid-cols-5 mb-6">
          <TabsTrigger value="account" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            <span className="hidden md:inline">Account</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span className="hidden md:inline">Security</span>
          </TabsTrigger>
          <TabsTrigger value="backup" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            <span className="hidden md:inline">Backup</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span className="hidden md:inline">Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span className="hidden md:inline">Documents</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="account" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Account Settings</CardTitle>
              <CardDescription>
                Manage your account information and preferences.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input id="fullName" defaultValue="Admin User" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input id="email" type="email" defaultValue="admin@example.com" />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" defaultValue="+91 98765 43210" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="role">Role</Label>
                    <Input id="role" defaultValue="Administrator" disabled />
                  </div>
                </div>
              </div>
              
              <div>
                <Button 
                  className="mt-4"
                  onClick={() => {
                    toast({
                      title: "Account Updated",
                      description: "Your account information has been saved successfully.",
                    });
                  }}
                >
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Application Settings</CardTitle>
              <CardDescription>
                Customize global application behavior.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="defaultDailyAmount">Default Daily Amount</Label>
                  <Input id="defaultDailyAmount" type="number" defaultValue="500" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currency">Currency Format</Label>
                  <Select defaultValue="inr">
                    <SelectTrigger id="currency">
                      <SelectValue placeholder="Select currency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="inr">Indian Rupee (₹)</SelectItem>
                      <SelectItem value="usd">US Dollar ($)</SelectItem>
                      <SelectItem value="eur">Euro (€)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dateFormat">Date Format</Label>
                  <Select defaultValue="dd-mm-yyyy">
                    <SelectTrigger id="dateFormat">
                      <SelectValue placeholder="Select date format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dd-mm-yyyy">DD-MM-YYYY</SelectItem>
                      <SelectItem value="mm-dd-yyyy">MM-DD-YYYY</SelectItem>
                      <SelectItem value="yyyy-mm-dd">YYYY-MM-DD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="language">Language</Label>
                  <Select defaultValue="en">
                    <SelectTrigger id="language">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="hi">Hindi</SelectItem>
                      <SelectItem value="ta">Tamil</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Button 
                  className="mt-4"
                  onClick={() => {
                    toast({
                      title: "Settings Updated",
                      description: "Application settings have been saved successfully.",
                    });
                  }}
                >
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Password Settings</CardTitle>
              <CardDescription>
                Change your password and security preferences.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">Current Password</Label>
                  <Input id="currentPassword" type="password" />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <Input id="newPassword" type="password" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                    <Input id="confirmPassword" type="password" />
                  </div>
                </div>
              </div>
              
              <div>
                <Button 
                  className="mt-4"
                  onClick={() => {
                    toast({
                      title: "Password Updated",
                      description: "Your password has been changed successfully.",
                    });
                  }}
                >
                  Update Password
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Login Security</CardTitle>
              <CardDescription>
                Configure additional security features for your account.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="twoFactor">Two-Factor Authentication</Label>
                  <p className="text-sm text-gray-500">
                    Receive an OTP on your phone when logging in
                  </p>
                </div>
                <Switch id="twoFactor" />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="autoLogout">Auto Logout</Label>
                  <p className="text-sm text-gray-500">
                    Automatically log out after 30 minutes of inactivity
                  </p>
                </div>
                <Switch id="autoLogout" defaultChecked />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="loginAttempts">Maximum Login Attempts</Label>
                <Select defaultValue="5">
                  <SelectTrigger id="loginAttempts">
                    <SelectValue placeholder="Select maximum attempts" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 Attempts</SelectItem>
                    <SelectItem value="5">5 Attempts</SelectItem>
                    <SelectItem value="10">10 Attempts</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Button 
                  className="mt-4"
                  onClick={() => {
                    toast({
                      title: "Security Settings Updated",
                      description: "Your security preferences have been saved.",
                    });
                  }}
                >
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backup" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Backup Settings</CardTitle>
              <CardDescription>
                Configure automatic backup settings for your data.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="backupFrequency">Backup Frequency</Label>
                  <Select 
                    value={backupSettings?.value || "weekly"} 
                    onValueChange={(value) => handleUpdateSetting("backup_frequency", value)}
                    disabled={backupSettingsLoading}
                  >
                    <SelectTrigger id="backupFrequency">
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                      <SelectItem value="manual">Manual Only</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="backupDay">Backup Day</Label>
                  <Select defaultValue="sunday">
                    <SelectTrigger id="backupDay">
                      <SelectValue placeholder="Select day" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monday">Monday</SelectItem>
                      <SelectItem value="tuesday">Tuesday</SelectItem>
                      <SelectItem value="wednesday">Wednesday</SelectItem>
                      <SelectItem value="thursday">Thursday</SelectItem>
                      <SelectItem value="friday">Friday</SelectItem>
                      <SelectItem value="saturday">Saturday</SelectItem>
                      <SelectItem value="sunday">Sunday</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="backupTime">Backup Time</Label>
                  <Input id="backupTime" type="time" defaultValue="00:00" />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="retentionPeriod">Retention Period</Label>
                  <Select defaultValue="30">
                    <SelectTrigger id="retentionPeriod">
                      <SelectValue placeholder="Select retention period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 Days</SelectItem>
                      <SelectItem value="30">30 Days</SelectItem>
                      <SelectItem value="90">90 Days</SelectItem>
                      <SelectItem value="365">1 Year</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
                <Button 
                  className="mt-4" 
                  onClick={() => {
                    toast({
                      title: "Backup Settings Saved",
                      description: "Your backup settings have been updated.",
                    });
                  }}
                >
                  <Save className="mr-2 h-4 w-4" />
                  Save Settings
                </Button>
                
                <Button 
                  className="mt-4"
                  variant="outline"
                  onClick={handleBackupNow}
                >
                  <Database className="mr-2 h-4 w-4" />
                  Backup Now
                </Button>
                
                <Button 
                  className="mt-4"
                  variant="outline"
                  onClick={() => setRestoreDialogOpen(true)}
                >
                  Restore from Backup
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Backup History</CardTitle>
              <CardDescription>
                View and restore from previous backups.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="rounded-md border">
                  <div className="divide-y">
                    <div className="px-4 py-3 flex items-center justify-between">
                      <div>
                        <p className="font-medium">backup-1720001234.json</p>
                        <p className="text-sm text-gray-500">Sunday, July 2, 2023 12:00 AM • 1.2 MB</p>
                      </div>
                      <div>
                        <Button variant="ghost" size="sm">Restore</Button>
                        <Button variant="ghost" size="sm">Download</Button>
                      </div>
                    </div>
                    
                    <div className="px-4 py-3 flex items-center justify-between">
                      <div>
                        <p className="font-medium">backup-1719396834.json</p>
                        <p className="text-sm text-gray-500">Sunday, June 25, 2023 12:00 AM • 1.1 MB</p>
                      </div>
                      <div>
                        <Button variant="ghost" size="sm">Restore</Button>
                        <Button variant="ghost" size="sm">Download</Button>
                      </div>
                    </div>
                    
                    <div className="px-4 py-3 flex items-center justify-between">
                      <div>
                        <p className="font-medium">backup-1718792234.json</p>
                        <p className="text-sm text-gray-500">Sunday, June 18, 2023 12:00 AM • 1.0 MB</p>
                      </div>
                      <div>
                        <Button variant="ghost" size="sm">Restore</Button>
                        <Button variant="ghost" size="sm">Download</Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>SMS Notifications</CardTitle>
              <CardDescription>
                Configure SMS notifications and reminders for members.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="smsReminders">SMS Reminders</Label>
                  <p className="text-sm text-gray-500">
                    Send payment reminders via SMS
                  </p>
                </div>
                <Switch 
                  id="smsReminders"
                  checked={smsSettings?.value === "enabled"}
                  onCheckedChange={(checked) => 
                    handleUpdateSetting("sms_reminders", checked ? "enabled" : "disabled")
                  }
                  disabled={smsSettingsLoading}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="smsProvider">SMS Provider</Label>
                <Select defaultValue="twilio">
                  <SelectTrigger id="smsProvider">
                    <SelectValue placeholder="Select SMS provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="twilio">Twilio</SelectItem>
                    <SelectItem value="msg91">MSG91</SelectItem>
                    <SelectItem value="custom">Custom Provider</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="apiKey">API Key</Label>
                <Input id="apiKey" type="password" defaultValue="••••••••••••••••" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="senderId">Sender ID</Label>
                <Input id="senderId" defaultValue="FINAPP" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="reminderTemplate">Reminder Template</Label>
                <Input 
                  id="reminderTemplate" 
                  defaultValue="Hello {name}, your payment of {amount} is due today. Please make the payment to avoid late fees." 
                />
                <p className="text-xs text-gray-500">
                  Use {name}, {amount}, {date}, {serialNo} as placeholders
                </p>
              </div>
              
              <div>
                <Button 
                  className="mt-4"
                  onClick={() => {
                    toast({
                      title: "SMS Settings Saved",
                      description: "Your SMS notification settings have been updated.",
                    });
                  }}
                >
                  Save Settings
                </Button>
                
                <Button 
                  className="mt-4 ml-2"
                  variant="outline"
                  onClick={() => {
                    toast({
                      title: "Test SMS Sent",
                      description: "A test SMS has been sent to your phone number.",
                    });
                  }}
                >
                  Send Test SMS
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>WhatsApp Notifications</CardTitle>
              <CardDescription>
                Configure WhatsApp notifications and reminders.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="whatsappReminders">WhatsApp Reminders</Label>
                  <p className="text-sm text-gray-500">
                    Send payment reminders via WhatsApp
                  </p>
                </div>
                <Switch id="whatsappReminders" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="whatsappProvider">WhatsApp Provider</Label>
                <Select defaultValue="twilio">
                  <SelectTrigger id="whatsappProvider">
                    <SelectValue placeholder="Select WhatsApp provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="twilio">Twilio</SelectItem>
                    <SelectItem value="gupshup">Gupshup</SelectItem>
                    <SelectItem value="360dialog">360dialog</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="whatsappApiKey">API Key</Label>
                <Input id="whatsappApiKey" type="password" defaultValue="••••••••••••••••" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="whatsappTemplate">Message Template</Label>
                <Input 
                  id="whatsappTemplate" 
                  defaultValue="Hello {name}, your payment of {amount} is due today. Please make the payment to avoid late fees." 
                />
              </div>
              
              <div>
                <Button 
                  className="mt-4"
                  onClick={() => {
                    toast({
                      title: "WhatsApp Settings Saved",
                      description: "Your WhatsApp notification settings have been updated.",
                    });
                  }}
                >
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Document Settings</CardTitle>
              <CardDescription>
                Configure document types and upload settings.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="documentVersion">Document Version Control</Label>
                  <Switch id="documentVersion" defaultChecked />
                </div>
                
                <div className="space-y-2">
                  <Label>Required Documents</Label>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Switch id="aadharRequired" defaultChecked />
                      <Label htmlFor="aadharRequired">Aadhaar Card</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch id="panRequired" defaultChecked />
                      <Label htmlFor="panRequired">PAN Card</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch id="agreementRequired" defaultChecked />
                      <Label htmlFor="agreementRequired">Loan Agreement</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch id="photoRequired" />
                      <Label htmlFor="photoRequired">Photograph</Label>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="maxFileSize">Maximum File Size</Label>
                  <Select defaultValue="5">
                    <SelectTrigger id="maxFileSize">
                      <SelectValue placeholder="Select maximum file size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2">2 MB</SelectItem>
                      <SelectItem value="5">5 MB</SelectItem>
                      <SelectItem value="10">10 MB</SelectItem>
                      <SelectItem value="20">20 MB</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="allowedFileTypes">Allowed File Types</Label>
                  <div className="flex flex-wrap gap-2">
                    <div className="flex items-center h-10 px-4 border rounded-md bg-gray-100">
                      <span className="text-sm">PDF</span>
                    </div>
                    <div className="flex items-center h-10 px-4 border rounded-md bg-gray-100">
                      <span className="text-sm">JPG/JPEG</span>
                    </div>
                    <div className="flex items-center h-10 px-4 border rounded-md bg-gray-100">
                      <span className="text-sm">PNG</span>
                    </div>
                    <Button variant="outline" size="sm" className="h-10">
                      + Add
                    </Button>
                  </div>
                </div>
              </div>
              
              <div>
                <Button 
                  className="mt-4"
                  onClick={() => {
                    toast({
                      title: "Document Settings Saved",
                      description: "Your document settings have been updated.",
                    });
                  }}
                >
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Custom Document Types</CardTitle>
              <CardDescription>
                Add custom document types for member records.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="rounded-md border">
                <div className="divide-y">
                  <div className="px-4 py-3 flex items-center justify-between">
                    <span>Aadhaar Card</span>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm">Edit</Button>
                      <Button variant="ghost" size="sm" className="text-red-500">Delete</Button>
                    </div>
                  </div>
                  
                  <div className="px-4 py-3 flex items-center justify-between">
                    <span>PAN Card</span>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm">Edit</Button>
                      <Button variant="ghost" size="sm" className="text-red-500">Delete</Button>
                    </div>
                  </div>
                  
                  <div className="px-4 py-3 flex items-center justify-between">
                    <span>Loan Agreement</span>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm">Edit</Button>
                      <Button variant="ghost" size="sm" className="text-red-500">Delete</Button>
                    </div>
                  </div>
                  
                  <div className="px-4 py-3 flex items-center justify-between">
                    <span>Address Proof</span>
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm">Edit</Button>
                      <Button variant="ghost" size="sm" className="text-red-500">Delete</Button>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <Button 
                  variant="outline"
                  onClick={() => {
                    toast({
                      title: "Add Document Type",
                      description: "This feature will be implemented soon!",
                    });
                  }}
                >
                  Add Document Type
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Backup Confirmation Dialog */}
      <AlertDialog open={backupConfirmOpen} onOpenChange={setBackupConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Create Backup</AlertDialogTitle>
            <AlertDialogDescription>
              This will create a backup of all your data. This process cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmBackup}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Restore Dialog */}
      <Dialog open={restoreDialogOpen} onOpenChange={setRestoreDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Restore from Backup</DialogTitle>
            <DialogDescription>
              Select a backup file to restore your data. This will replace all current data.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="backupFile">Backup File</Label>
              <div className="flex items-center gap-2">
                <Input id="backupFile" type="file" />
                <Button variant="outline" size="sm">Browse</Button>
              </div>
            </div>
            
            <div className="rounded-md bg-amber-50 p-4 flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-amber-800">Warning</h4>
                <p className="text-sm text-amber-700 mt-1">
                  Restoring from a backup will replace all your current data. This action cannot be undone.
                </p>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setRestoreDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleRestore}>
              Restore Data
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
