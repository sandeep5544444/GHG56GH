import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import PaymentCollectionModal from "@/components/modals/payment-collection-modal";
import MemberFormModal from "@/components/modals/member-form-modal";
import { Member } from "@shared/schema";
import { formatCurrency, formatDate, getInitials, getRandomColor } from "@/lib/utils";
import { 
  Plus, 
  Download, 
  Search, 
  Grid, 
  List, 
  Edit, 
  Trash, 
  FileText,
  AlertTriangle,
  RefreshCcw 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSearchContext } from "@/context/app-context";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Members() {
  const [view, setView] = useState<"grid" | "list">("grid");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showAddMemberModal, setShowAddMemberModal] = useState(false);
  const [editMember, setEditMember] = useState<Member | undefined>(undefined);
  const [showEditMemberModal, setShowEditMemberModal] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [memberToDelete, setMemberToDelete] = useState<Member | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedMemberId, setSelectedMemberId] = useState<number | null>(null);
  
  const { searchQuery } = useSearchContext();
  const { toast } = useToast();

  // Fetch members data
  const { 
    data: members, 
    isLoading, 
    refetch 
  } = useQuery<Member[]>({
    queryKey: ['/api/members'],
  });

  // Delete member mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/members/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Member Deleted",
        description: "Member has been successfully deleted",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/members'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
    },
    onError: (error) => {
      console.error("Error deleting member:", error);
      toast({
        title: "Error",
        description: "Failed to delete member. Please try again.",
        variant: "destructive"
      });
    },
  });

  const handleExport = () => {
    toast({
      title: "Export Started",
      description: "Your members data export is being prepared",
    });
  };

  const handleAddMember = () => {
    setShowAddMemberModal(true);
  };

  const handleEditMember = (member: Member) => {
    setEditMember(member);
    setShowEditMemberModal(true);
  };

  const handleDeleteMember = (member: Member) => {
    setMemberToDelete(member);
    setShowDeleteDialog(true);
  };

  const confirmDeleteMember = () => {
    if (memberToDelete) {
      deleteMutation.mutate(memberToDelete.id);
      setShowDeleteDialog(false);
      setMemberToDelete(null);
    }
  };

  const handleMakePayment = (memberId: number | null) => {
    if (memberId === null) return;
    setSelectedMemberId(memberId);
    setShowPaymentModal(true);
  };

  const handleViewDocuments = (id: number | null) => {
    if (id === null) return;
    toast({
      title: "Member Documents",
      description: `Viewing documents for member ID: ${id}`,
    });
  };

  // Filter members based on search query and status
  const filteredMembers = members ? members.filter(member => {
    // Filter by search query
    const matchesQuery = !searchQuery || 
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.mobileNumber.includes(searchQuery) ||
      member.serialNumber.toLowerCase().includes(searchQuery.toLowerCase());
    
    // Filter by status
    const matchesStatus = 
      statusFilter === "all" ||
      (statusFilter === "active" && member.isActive) ||
      (statusFilter === "inactive" && !member.isActive);
    
    return matchesQuery && matchesStatus;
  }) : [];

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Members</h1>
        <div className="flex space-x-2">
          <Button 
            variant="outline"
            className="hidden md:flex"
            onClick={handleExport}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button onClick={handleAddMember} className="bg-primary-600 hover:bg-primary-700">
            <Plus className="mr-2 h-4 w-4" />
            Add Member
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle>Member List</CardTitle>
            <div className="flex items-center space-x-2">
              <Tabs 
                defaultValue="all" 
                value={statusFilter}
                onValueChange={setStatusFilter}
                className="w-auto"
              >
                <TabsList>
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="active">Active</TabsTrigger>
                  <TabsTrigger value="inactive">Inactive</TabsTrigger>
                </TabsList>
              </Tabs>
              <div className="flex border rounded-md p-1">
                <Button
                  variant={view === "grid" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => setView("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={view === "list" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => setView("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
              <Button
                variant="outline"
                size="sm"
                className="h-8 px-2"
                onClick={() => refetch()}
              >
                <RefreshCcw className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            view === "grid" ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array(6).fill(0).map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-4 mb-4">
                        <div className="h-12 w-12 rounded-full bg-gray-200"></div>
                        <div className="space-y-2">
                          <div className="h-4 w-24 bg-gray-200 rounded"></div>
                          <div className="h-3 w-32 bg-gray-200 rounded"></div>
                        </div>
                      </div>
                      <div className="space-y-3">
                        <div className="h-3 w-full bg-gray-200 rounded"></div>
                        <div className="h-3 w-3/4 bg-gray-200 rounded"></div>
                        <div className="h-3 w-2/3 bg-gray-200 rounded"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Serial No.</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Mobile</TableHead>
                      <TableHead>Loan Amount</TableHead>
                      <TableHead>Daily Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Array(5).fill(0).map((_, i) => (
                      <TableRow key={i}>
                        <TableCell className="animate-pulse">
                          <div className="h-4 bg-gray-200 rounded w-16"></div>
                        </TableCell>
                        <TableCell className="animate-pulse">
                          <div className="h-4 bg-gray-200 rounded w-24"></div>
                        </TableCell>
                        <TableCell className="animate-pulse">
                          <div className="h-4 bg-gray-200 rounded w-20"></div>
                        </TableCell>
                        <TableCell className="animate-pulse">
                          <div className="h-4 bg-gray-200 rounded w-16"></div>
                        </TableCell>
                        <TableCell className="animate-pulse">
                          <div className="h-4 bg-gray-200 rounded w-14"></div>
                        </TableCell>
                        <TableCell className="animate-pulse">
                          <div className="h-6 bg-gray-200 rounded w-16"></div>
                        </TableCell>
                        <TableCell className="animate-pulse">
                          <div className="h-6 bg-gray-200 rounded w-24"></div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )
          ) : filteredMembers.length === 0 ? (
            <div className="py-8 text-center">
              <Search className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-base font-semibold text-gray-900">No members found</h3>
              <p className="mt-1 text-sm text-gray-500">
                {searchQuery ? "Try adjusting your search query." : "Start by adding a new member."}
              </p>
              <div className="mt-6">
                <Button onClick={handleAddMember} className="bg-primary-600 hover:bg-primary-700">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Member
                </Button>
              </div>
            </div>
          ) : view === "grid" ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredMembers.map((member) => (
                <Card key={member.id} className="overflow-hidden">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className={`h-12 w-12 rounded-full ${getRandomColor()} flex items-center justify-center text-lg font-medium`}>
                          {getInitials(member.name)}
                        </div>
                        <div>
                          <h3 className="text-base font-semibold">{member.name}</h3>
                          <p className="text-sm text-gray-500">{member.mobileNumber}</p>
                          <p className="text-xs text-gray-500">ID: {member.serialNumber}</p>
                        </div>
                      </div>
                      <div className="flex space-x-1">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0"
                          onClick={() => handleEditMember(member)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0 text-red-500"
                          onClick={() => handleDeleteMember(member)}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <div className="space-y-3 mt-4">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-xs text-gray-500">Loan Amount</p>
                          <p className="text-sm font-medium">{formatCurrency(member.loanAmount)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Daily Amount</p>
                          <p className="text-sm font-medium">{formatCurrency(member.dailyAmount)}</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-xs text-gray-500">Total Paid</p>
                          <p className="text-sm font-medium">{formatCurrency(member.totalPaid)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Pending</p>
                          <p className="text-sm font-medium text-red-600">{formatCurrency(member.pending)}</p>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-xs text-gray-500">Start Date</p>
                          <p className="text-sm font-medium">{formatDate(member.startDate)}</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500">Last Paid</p>
                          <p className="text-sm font-medium">{member.lastPaidDate ? formatDate(member.lastPaidDate) : 'Never'}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-4 pt-3 border-t border-gray-100 flex justify-between">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="text-primary-600"
                        onClick={() => handleViewDocuments(member.id)}
                      >
                        <FileText className="h-4 w-4 mr-1" />
                        Documents
                      </Button>
                      <Button 
                        size="sm"
                        onClick={() => handleMakePayment(member.id)}
                      >
                        Make Payment
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Serial No.</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Mobile</TableHead>
                    <TableHead>Loan Amount</TableHead>
                    <TableHead>Daily Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMembers.map((member) => (
                    <TableRow key={member.id}>
                      <TableCell>{member.serialNumber}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <div className={`h-8 w-8 rounded-full ${getRandomColor()} flex items-center justify-center text-sm font-medium`}>
                            {getInitials(member.name)}
                          </div>
                          <span>{member.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>{member.mobileNumber}</TableCell>
                      <TableCell>{formatCurrency(member.loanAmount)}</TableCell>
                      <TableCell>{formatCurrency(member.dailyAmount)}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          member.isActive
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {member.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0"
                            onClick={() => handleEditMember(member)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0"
                            onClick={() => handleViewDocuments(member.id)}
                          >
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="h-8 w-8 p-0 text-red-500"
                            onClick={() => handleDeleteMember(member)}
                          >
                            <Trash className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Member Modal */}
      <MemberFormModal
        isOpen={showAddMemberModal}
        onClose={() => setShowAddMemberModal(false)}
        mode="create"
      />

      {/* Edit Member Modal */}
      {editMember && (
        <MemberFormModal
          isOpen={showEditMemberModal}
          onClose={() => {
            setShowEditMemberModal(false);
            setEditMember(undefined);
          }}
          member={editMember}
          mode="edit"
        />
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <AlertTriangle className="h-5 w-5" />
              Confirm Deletion
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete member <span className="font-medium">{memberToDelete?.name}</span>? 
              This action cannot be undone and all associated payment records will remain.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDeleteMember}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Payment Collection Modal */}
      {showPaymentModal && (
        <PaymentCollectionModal
          isOpen={showPaymentModal}
          onClose={() => {
            setShowPaymentModal(false);
            setSelectedMemberId(null);
          }}
          initialMemberId={selectedMemberId || undefined}
        />
      )}
    </div>
  );
}
