import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer, 
  PieChart,
  Pie,
  Cell
} from "recharts";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format, subDays, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay } from "date-fns";
import { Member, Payment } from "@shared/schema";
import { formatCurrency, formatDate } from "@/lib/utils";
import { 
  Download, 
  Calendar as CalendarIcon, 
  AlertTriangle, 
  Mail 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const COLORS = ["#3b82f6", "#93c5fd", "#bfdbfe", "#dbeafe"];

import { useEffect } from 'react';

export default function Reports() {
  const [reportType, setReportType] = useState("daily");
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined;
    to: Date | undefined;
  }>({
    from: subDays(new Date(), 7),
    to: new Date(),
  });
  const [statusFilter, setStatusFilter] = useState("all");
  
  const { toast } = useToast();

  // Fetch data based on selected report type and date range
  const { data: payments, isLoading: paymentsLoading } = useQuery<Payment[]>({
    queryKey: ['/api/payments'],
  });

  const { data: members, isLoading: membersLoading } = useQuery<Member[]>({
    queryKey: ['/api/members'],
  });

  const handleExport = () => {
    toast({
      title: "Export Started",
      description: `Your ${reportType} report is being prepared`,
    });
  };

  const handleEmailReport = () => {
    toast({
      title: "Email Report",
      description: "Report has been sent to your email",
    });
  };

  // Filter data based on date range and status
  const filteredPayments = payments?.filter(payment => {
    try {
      const paymentDate = new Date(payment.paymentDate);
      if (isNaN(paymentDate.getTime())) {
        console.warn(`Invalid payment date: ${payment.paymentDate}`);
        return false;
      }

      const isInDateRange = 
        (!dateRange.from || paymentDate >= dateRange.from) && 
        (!dateRange.to || paymentDate <= dateRange.to);
      
      const matchesStatus = 
        statusFilter === "all" ||
        (statusFilter === "paid" && payment.isPaid) ||
        (statusFilter === "unpaid" && !payment.isPaid);
      
      return isInDateRange && matchesStatus;
    } catch (err) {
      console.error("Error filtering payment:", err);
      return false;
    }
  }) || [];

  // Validate date range
  useEffect(() => {
    if (dateRange.from && dateRange.to && dateRange.from > dateRange.to) {
      toast({
        title: "Invalid Date Range",
        description: "Start date must be before end date",
        variant: "destructive"
      });
      setDateRange({ from: undefined, to: undefined });
    }
  }, [dateRange]);

  // Calculate daily collection data (for chart)
  const getDailyCollectionData = () => {
    if (!dateRange.from || !dateRange.to || !payments) return [];
    
    // Limit range to max 31 days to prevent performance issues
    const daysDiff = differenceInDays(dateRange.to, dateRange.from);
    if (daysDiff > 31) {
      toast({
        title: "Date Range Too Large",
        description: "Please select a range of 31 days or less",
        variant: "destructive"
      });
      return [];
    }
    
    const days = eachDayOfInterval({
      start: dateRange.from,
      end: dateRange.to
    });

    // Create a map for faster lookups
    const paymentsByDate = new Map();
    payments.forEach(payment => {
      const date = startOfDay(new Date(payment.paymentDate)).getTime();
      const existing = paymentsByDate.get(date) || { total: 0, count: 0 };
      if (payment.isPaid) {
        existing.total += payment.amount + (payment.advanceAmount || 0);
        existing.count++;
      }
      paymentsByDate.set(date, existing);
    });
    
    return days.map(day => {
      const dayPayments = payments.filter(payment => 
        isSameDay(new Date(payment.paymentDate), day) && payment.isPaid
      );
      
      const totalAmount = dayPayments.reduce(
        (sum, payment) => sum + payment.amount + (payment.advanceAmount || 0), 
        0
      );
      
      return {
        name: format(day, 'dd MMM'),
        amount: totalAmount,
        count: dayPayments.length
      };
    });
  };

  // Calculate overdue data
  const getOverdueData = () => {
    if (!members) return [];
    
    const now = new Date();
    const overdueCategories = [
      { name: "1-3 Days", count: 0, amount: 0 },
      { name: "4-7 Days", count: 0, amount: 0 },
      { name: "8-14 Days", count: 0, amount: 0 },
      { name: "15+ Days", count: 0, amount: 0 }
    ];
    
    members.forEach(member => {
      if (!member.lastPaidDate || !member.isActive || !member.dailyAmount) return;
      
      const lastPaid = new Date(member.lastPaidDate);
      const daysDiff = Math.floor((now.getTime() - lastPaid.getTime()) / (1000 * 60 * 60 * 24));
      const dailyAmount = Number(member.dailyAmount);
      
      if (daysDiff >= 1 && daysDiff <= 3) {
        overdueCategories[0].count++;
        overdueCategories[0].amount += Math.round(dailyAmount * daysDiff * 100) / 100;
      } else if (daysDiff >= 4 && daysDiff <= 7) {
        overdueCategories[1].count++;
        overdueCategories[1].amount += Math.round(dailyAmount * daysDiff * 100) / 100;
      } else if (daysDiff >= 8 && daysDiff <= 14) {
        overdueCategories[2].count++;
        overdueCategories[2].amount += Math.round(dailyAmount * daysDiff * 100) / 100;
      } else if (daysDiff >= 15) {
        overdueCategories[3].count++;
        overdueCategories[3].amount += Math.round(dailyAmount * daysDiff * 100) / 100;
      }
    });
    
    return overdueCategories;
  };
  
  // Calculate collection status data for pie chart
  const getCollectionStatusData = () => {
    if (!members) return [];
    
    const totalMembers = members.filter(m => m.isActive).length;
    const paidToday = new Set(
      payments?.filter(p => 
        isSameDay(new Date(p.paymentDate), new Date()) && p.isPaid
      ).map(p => p.memberId)
    ).size;
    
    return [
      { name: "Paid", value: paidToday },
      { name: "Unpaid", value: totalMembers - paidToday }
    ];
  };

  // Generate report data based on the selected type
  const getDynamicReportData = () => {
    switch (reportType) {
      case "daily":
        return getDailyCollectionData();
      case "overdue":
        return getOverdueData();
      default:
        return [];
    }
  };

  const isLoading = paymentsLoading || membersLoading;
  const reportData = getDynamicReportData();
  const collectionStatusData = getCollectionStatusData();

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <h1 className="text-2xl font-bold">Reports</h1>
        
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          
          <Button variant="outline" onClick={handleEmailReport}>
            <Mail className="mr-2 h-4 w-4" />
            Email Report
          </Button>
        </div>
      </div>

      <Tabs defaultValue="daily" onValueChange={setReportType}>
        <div className="flex justify-between items-center mb-4">
          <TabsList>
            <TabsTrigger value="daily">Daily Report</TabsTrigger>
            <TabsTrigger value="weekly">Weekly Summary</TabsTrigger>
            <TabsTrigger value="monthly">Monthly Summary</TabsTrigger>
            <TabsTrigger value="overdue">Overdue Analysis</TabsTrigger>
          </TabsList>
          
          <div className="flex space-x-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateRange.from ? (
                    dateRange.to ? (
                      <>
                        {format(dateRange.from, "LLL dd, y")} -{" "}
                        {format(dateRange.to, "LLL dd, y")}
                      </>
                    ) : (
                      format(dateRange.from, "LLL dd, y")
                    )
                  ) : (
                    <span>Pick a date range</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="range"
                  selected={dateRange}
                  onSelect={setDateRange}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="unpaid">Unpaid</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <TabsContent value="daily" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Daily Collection Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Daily Collection Trend</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="h-80 flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : reportData.length === 0 ? (
                  <div className="h-80 flex items-center justify-center">
                    <div className="text-center">
                      <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
                      <h3 className="text-lg font-medium">No data available</h3>
                      <p className="text-sm text-gray-500">
                        Try selecting a different date range.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={reportData}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="name" />
                        <YAxis 
                          tickFormatter={(value) => formatCurrency(value).replace('₹', '')}
                        />
                        <Tooltip 
                          formatter={(value: number) => [formatCurrency(value), 'Amount']}
                        />
                        <Legend />
                        <Bar dataKey="amount" name="Collection Amount" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Today's Collection Status */}
            <Card>
              <CardHeader>
                <CardTitle>Today's Collection Status</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="h-80 flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : collectionStatusData.length === 0 ? (
                  <div className="h-80 flex items-center justify-center">
                    <div className="text-center">
                      <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto mb-4" />
                      <h3 className="text-lg font-medium">No data available</h3>
                    </div>
                  </div>
                ) : (
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={collectionStatusData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        >
                          {collectionStatusData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value: number) => [value, 'Members']} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          {/* Payments Table */}
          <Card>
            <CardHeader>
              <CardTitle>Payment Details</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-8 flex justify-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                </div>
              ) : filteredPayments.length === 0 ? (
                <div className="py-8 text-center">
                  <AlertTriangle className="mx-auto h-12 w-12 text-amber-500" />
                  <h3 className="mt-2 text-base font-semibold text-gray-900">No payments found</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Try adjusting your filters or date range.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Member ID</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Notes</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPayments.map((payment) => (
                        <TableRow key={payment.id} className="hover:bg-gray-50">
                          <TableCell>{formatDate(payment.paymentDate)}</TableCell>
                          <TableCell>{payment.memberId}</TableCell>
                          <TableCell>{formatCurrency(payment.amount + (payment.advanceAmount || 0))}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              payment.isPaid
                                ? 'bg-green-100 text-green-800'
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {payment.isPaid ? 'Paid' : 'Unpaid'}
                            </span>
                          </TableCell>
                          <TableCell>{payment.notes || '-'}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="weekly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Weekly Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white p-4 rounded-lg border">
                    <h3 className="text-sm font-medium text-gray-500">Total Collection</h3>
                    <p className="text-2xl font-semibold mt-1">
                      {formatCurrency(
                        filteredPayments
                          .filter(p => p.isPaid)
                          .reduce((sum, p) => sum + p.amount + (p.advanceAmount || 0), 0)
                      )}
                    </p>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h3 className="text-sm font-medium text-gray-500">Paid Members</h3>
                    <p className="text-2xl font-semibold mt-1">
                      {new Set(filteredPayments.filter(p => p.isPaid).map(p => p.memberId)).size}
                    </p>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h3 className="text-sm font-medium text-gray-500">Collection Rate</h3>
                    <p className="text-2xl font-semibold mt-1">
                      {members && members.length > 0
                        ? `${Math.round((new Set(filteredPayments.filter(p => p.isPaid).map(p => p.memberId)).size / members.filter(m => m.isActive).length) * 100)}%`
                        : '0%'
                      }
                    </p>
                  </div>
                </div>
                
                <h3 className="text-lg font-medium mt-6">Daily Breakdown</h3>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Collection Amount</TableHead>
                        <TableHead>Members Paid</TableHead>
                        <TableHead>Collection Rate</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {getDailyCollectionData().map((day, index) => (
                        <TableRow key={index}>
                          <TableCell>{day.name}</TableCell>
                          <TableCell>{formatCurrency(day.amount)}</TableCell>
                          <TableCell>{day.count}</TableCell>
                          <TableCell>
                            {members && members.length > 0
                              ? `${Math.round((day.count / members.filter(m => m.isActive).length) * 100)}%`
                              : '0%'
                            }
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monthly" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-500 mb-4">
                Monthly collection summary for the selected date range.
              </p>
              
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white p-4 rounded-lg border">
                    <h3 className="text-sm font-medium text-gray-500">Monthly Target</h3>
                    <p className="text-2xl font-semibold mt-1">
                      {formatCurrency(
                        members 
                          ? members.filter(m => m.isActive).reduce((sum, m) => sum + (m.dailyAmount * 22), 0)
                          : 0
                      )}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">Based on 22 working days</p>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h3 className="text-sm font-medium text-gray-500">Collected Amount</h3>
                    <p className="text-2xl font-semibold mt-1">
                      {formatCurrency(
                        filteredPayments
                          .filter(p => p.isPaid)
                          .reduce((sum, p) => sum + p.amount + (p.advanceAmount || 0), 0)
                      )}
                    </p>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg border">
                    <h3 className="text-sm font-medium text-gray-500">Achievement</h3>
                    <p className="text-2xl font-semibold mt-1">
                      {members && members.length > 0
                        ? `${Math.round((filteredPayments
                            .filter(p => p.isPaid)
                            .reduce((sum, p) => sum + p.amount + (p.advanceAmount || 0), 0) / 
                            (members.filter(m => m.isActive).reduce((sum, m) => sum + (m.dailyAmount * 22), 0))) * 100)}%`
                        : '0%'
                      }
                    </p>
                  </div>
                </div>
                
                <div className="h-80">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={getDailyCollectionData()}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" />
                      <YAxis 
                        tickFormatter={(value) => formatCurrency(value).replace('₹', '')}
                      />
                      <Tooltip 
                        formatter={(value: number) => [formatCurrency(value), 'Amount']}
                      />
                      <Legend />
                      <Bar dataKey="amount" name="Collection Amount" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="overdue" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Overdue Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {getOverdueData().map((category, index) => (
                    <div key={index} className="bg-white p-4 rounded-lg border">
                      <h3 className="text-sm font-medium text-gray-500">{category.name}</h3>
                      <p className="text-2xl font-semibold mt-1">{category.count}</p>
                      <p className="text-sm text-red-600 mt-1">{formatCurrency(category.amount)}</p>
                    </div>
                  ))}
                </div>
                
                {/* Overdue Members Table */}
                <Card>
                  <CardHeader>
                    <CardTitle>Overdue Members</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Serial No.</TableHead>
                            <TableHead>Name</TableHead>
                            <TableHead>Mobile Number</TableHead>
                            <TableHead>Last Paid Date</TableHead>
                            <TableHead>Overdue Days</TableHead>
                            <TableHead>Pending Amount</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {members && members
                            .filter(member => {
                              if (!member.lastPaidDate || !member.isActive) return false;
                              const lastPaid = new Date(member.lastPaidDate);
                              const daysDiff = Math.floor((new Date().getTime() - lastPaid.getTime()) / (1000 * 60 * 60 * 24));
                              return daysDiff > 0;
                            })
                            .sort((a, b) => {
                              const aDate = a.lastPaidDate ? new Date(a.lastPaidDate).getTime() : 0;
                              const bDate = b.lastPaidDate ? new Date(b.lastPaidDate).getTime() : 0;
                              return aDate - bDate; // Sort by oldest first
                            })
                            .slice(0, 10) // Limit to 10 for display
                            .map(member => {
                              const lastPaid = new Date(member.lastPaidDate!);
                              const daysDiff = Math.floor((new Date().getTime() - lastPaid.getTime()) / (1000 * 60 * 60 * 24));
                              return (
                                <TableRow key={member.id}>
                                  <TableCell>{member.serialNumber}</TableCell>
                                  <TableCell>{member.name}</TableCell>
                                  <TableCell>{member.mobileNumber}</TableCell>
                                  <TableCell>{formatDate(member.lastPaidDate!)}</TableCell>
                                  <TableCell>{daysDiff}</TableCell>
                                  <TableCell>{formatCurrency(member.dailyAmount * daysDiff)}</TableCell>
                                  <TableCell>
                                    <Button 
                                      variant="ghost" 
                                      size="sm" 
                                      className="text-primary-600"
                                      onClick={() => {
                                        toast({
                                          title: "Collection Reminder",
                                          description: `Reminder sent to ${member.name}`,
                                        });
                                      }}
                                    >
                                      Send Reminder
                                    </Button>
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
