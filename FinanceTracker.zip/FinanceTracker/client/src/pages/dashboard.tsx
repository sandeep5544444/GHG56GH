
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import SummaryCard from "@/components/dashboard/summary-card";
import CollectionChart from "@/components/dashboard/collection-chart";
import AlertsPanel from "@/components/dashboard/alerts-panel";
import PaymentTable from "@/components/dashboard/payment-table";
import { 
  DollarSign, 
  CalendarCheck, 
  Wallet, 
  PieChart,
  AlertTriangle
} from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { DashboardSummary } from "../../../server/storage";

export default function Dashboard() {
  const { data, isLoading, error } = useQuery<DashboardSummary>({
    queryKey: ['/api/dashboard'],
  });

  if (error) {
    return (
      <div className="p-4 md:p-6">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <h3 className="text-red-800 font-medium">Error loading dashboard</h3>
          <p className="text-red-600 text-sm">Failed to fetch dashboard data. Please try again.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <SummaryCard
          title="Today's Collection"
          amount={data?.todayCollection.paidAmount || 0}
          subtitle={`(${data?.todayCollection.paidCount || 0} paid)`}
          subtitleAmount={data?.todayCollection.unpaidAmount}
          icon={<DollarSign className="text-xl" />}
          borderColor="border-primary-500"
          iconBgColor="bg-primary-50"
          iconColor="text-primary-600"
          linkText="View detailed report"
          linkUrl="/reports"
          loading={isLoading}
        />
        
        <SummaryCard
          title="This Month's Collection"
          amount={data?.monthlyCollection.totalAmount || 0}
          subtitle={`${data?.monthlyCollection.percentage || 0}% target`}
          subtitleAmount={data?.monthlyCollection.target}
          icon={<CalendarCheck className="text-xl" />}
          borderColor="border-secondary-500"
          iconBgColor="bg-green-50"
          iconColor="text-green-600"
          linkText="View monthly trend"
          linkUrl="/reports"
          loading={isLoading}
        />

        <SummaryCard
          title="Total Loan Distributed"
          amount={data?.loanSummary.totalDistributed || 0}
          subtitle={`Active members: ${data?.loanSummary.activeMembers || 0}`}
          icon={<Wallet className="text-xl" />}
          borderColor="border-accent-500"
          iconBgColor="bg-orange-50"
          iconColor="text-orange-600"
          linkText="View loan details"
          linkUrl="/members"
          loading={isLoading}
        />

        <SummaryCard
          title="Unpaid Members"
          amount={data?.todayCollection.unpaidCount || 0}
          subtitle="Not paid today"
          icon={<AlertTriangle className="text-xl" />}
          borderColor="border-red-500"
          iconBgColor="bg-red-50"
          iconColor="text-red-600"
          linkText="View unpaid list"
          linkUrl="/payments?filter=unpaid"
          loading={isLoading}
        />
      </div>

      {/* Middle Section - Charts and Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <CollectionChart loading={isLoading} />
        </div>
        
        <div>
          <AlertsPanel 
            alerts={data?.alerts}
            loading={isLoading} 
          />
        </div>
      </div>

      {/* Recent Activity Section */}
      <PaymentTable 
        payments={data?.recentPayments}
        loading={isLoading}
      />
    </div>
  );
}
