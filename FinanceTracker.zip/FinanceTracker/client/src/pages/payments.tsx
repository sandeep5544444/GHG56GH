import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Payment, Member } from "@shared/schema";
import { formatCurrency, formatDate, getInitials, getRandomColor } from "@/lib/utils";
import { 
  Download, 
  Calendar as CalendarIcon, 
  FileText,
  Check,
  X
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSearchContext } from "@/context/app-context";
import PaymentCollectionModal from "@/components/modals/payment-collection-modal";
import { cn } from "@/lib/utils";

interface PaymentWithMember extends Payment {
  member?: Member;
}

export default function Payments() {
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [statusFilter, setStatusFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedMemberId, setSelectedMemberId] = useState<number | null>(null);
  const { searchQuery } = useSearchContext();
  const { toast } = useToast();

  const itemsPerPage = 10;

  // Fetch payments for the selected date
  const {
    data: payments,
    isLoading,
    refetch
  } = useQuery<PaymentWithMember[]>({
    queryKey: ['/api/payments/date', date ? format(date, 'yyyy-MM-dd') : ''],
    enabled: !!date,
  });

  // Fetch members for member mapping
  const { data: members } = useQuery<Member[]>({
    queryKey: ['/api/members'],
  });

  // Combine payments with member data
  const paymentsWithMembers = payments?.map(payment => {
    const member = members?.find(m => m.id === payment.memberId);
    return { ...payment, member };
  }) || [];

  // Filter payments based on status and search
  const filteredPayments = paymentsWithMembers.filter(payment => {
    const matchesStatus = 
      statusFilter === "all" ||
      (statusFilter === "paid" && payment.isPaid) ||
      (statusFilter === "pending" && !payment.isPaid);
      
    const matchesSearch = !searchQuery || 
      (payment.member && (
        payment.member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        payment.member.mobileNumber.includes(searchQuery) ||
        payment.member.serialNumber.toLowerCase().includes(searchQuery.toLowerCase())
      ));
      
    return matchesStatus && matchesSearch;
  });

  // Pagination
  const totalPages = Math.ceil(filteredPayments.length / itemsPerPage);
  const paginatedPayments = filteredPayments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleStatusFilterChange = (value: string) => {
    setStatusFilter(value);
    setCurrentPage(1);
  };

  const handleExport = () => {
    toast({
      title: "Export Started",
      description: "Your payment data export is being prepared",
    });
  };

  const handleCollectPayment = (memberId: number) => {
    setSelectedMemberId(memberId);
    setShowPaymentModal(true);
  };

  const closePaymentModal = () => {
    setShowPaymentModal(false);
    setSelectedMemberId(null);
    refetch(); // Refresh data after payment submission
  };

  // Generate active members who haven't paid yet
  const unpaidMembers = members?.filter(member => 
    member.isActive && 
    !paymentsWithMembers.some(payment => 
      payment.memberId === member.id && payment.isPaid
    )
  ) || [];

  const handleMarkAsPaid = (memberId: number) => {
    handleCollectPayment(memberId);
  };

  const handleMarkAsNotPaid = (memberId: number) => {
    toast({
      title: "Payment Skipped",
      description: "Member has been marked as not paid for today",
    });
  };

  return (
    <div className="p-4 md:p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <h1 className="text-2xl font-bold">Daily Payments</h1>
        
        <div className="flex flex-wrap items-center gap-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="justify-start text-left font-normal h-10"
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {date ? format(date, 'PPP') : <span>Pick a date</span>}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                initialFocus
              />
            </PopoverContent>
          </Popover>
          
          <Select value={statusFilter} onValueChange={handleStatusFilterChange}>
            <SelectTrigger className="w-[160px] h-10">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Payments</SelectItem>
              <SelectItem value="paid">Paid</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          
          <Button onClick={() => setShowPaymentModal(true)}>
            Record Payment
          </Button>
        </div>
      </div>

      {/* Payment Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Collected</p>
                <h3 className="text-2xl font-semibold mt-1">
                  {formatCurrency(
                    paymentsWithMembers
                      .filter(p => p.isPaid)
                      .reduce((sum, p) => sum + p.amount + (p.advanceAmount || 0), 0)
                  )}
                </h3>
              </div>
              <div className="p-3 rounded-full bg-green-100 text-green-600">
                <Check className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Pending Collection</p>
                <h3 className="text-2xl font-semibold mt-1">
                  {formatCurrency(
                    unpaidMembers.reduce((sum, m) => sum + m.dailyAmount, 0)
                  )}
                </h3>
              </div>
              <div className="p-3 rounded-full bg-red-100 text-red-600">
                <X className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Payment Status</p>
                <h3 className="text-2xl font-semibold mt-1">
                  {paymentsWithMembers.filter(p => p.isPaid).length} / {paymentsWithMembers.filter(p => p.isPaid).length + unpaidMembers.length}
                </h3>
              </div>
              <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                <FileText className="h-6 w-6" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payments Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Payment Records for {date ? format(date, 'PPP') : 'Today'}</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-8 flex justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : paginatedPayments.length === 0 && unpaidMembers.length === 0 ? (
            <div className="py-8 text-center">
              <FileText className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-base font-semibold text-gray-900">No payments found</h3>
              <p className="mt-1 text-sm text-gray-500">
                {searchQuery 
                  ? "Try adjusting your search query." 
                  : "There are no payment records for the selected date."}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Serial No.</TableHead>
                    <TableHead>Member</TableHead>
                    <TableHead>Daily Amount</TableHead>
                    <TableHead>Paid Amount</TableHead>
                    <TableHead>Advance</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {/* Paid Members */}
                  {paginatedPayments.map((payment) => (
                    <TableRow key={payment.id} className="hover:bg-gray-50">
                      <TableCell>{payment.member?.serialNumber || '-'}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <div className={`h-8 w-8 rounded-full ${getRandomColor()} flex items-center justify-center text-sm font-medium`}>
                            {getInitials(payment.member?.name || 'Unknown')}
                          </div>
                          <div>
                            <div className="font-medium">{payment.member?.name || 'Unknown'}</div>
                            <div className="text-xs text-gray-500">{payment.member?.mobileNumber || '-'}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{formatCurrency(payment.member?.dailyAmount || 0)}</TableCell>
                      <TableCell>{formatCurrency(payment.amount)}</TableCell>
                      <TableCell>{payment.advanceAmount ? formatCurrency(payment.advanceAmount) : '-'}</TableCell>
                      <TableCell>{format(new Date(payment.paymentDate), 'h:mm a')}</TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          payment.isPaid
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {payment.isPaid ? 'Paid' : 'Pending'}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="text-primary-600 h-8 px-2"
                          onClick={() => payment.isPaid 
                            ? toast({ 
                                title: "Payment Details", 
                                description: `Viewing payment details for ${payment.member?.name || 'Unknown'}`
                              })
                            : handleMarkAsPaid(payment.memberId)
                          }
                        >
                          {payment.isPaid ? 'View' : 'Collect'}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  
                  {/* Unpaid Members (only show on current date and when status filter allows) */}
                  {(statusFilter === "all" || statusFilter === "pending") && 
                   date?.toDateString() === new Date().toDateString() &&
                   unpaidMembers.map((member) => (
                    <TableRow key={`unpaid-${member.id}`} className="hover:bg-gray-50 bg-gray-50">
                      <TableCell>{member.serialNumber}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <div className={`h-8 w-8 rounded-full ${getRandomColor()} flex items-center justify-center text-sm font-medium`}>
                            {getInitials(member.name)}
                          </div>
                          <div>
                            <div className="font-medium">{member.name}</div>
                            <div className="text-xs text-gray-500">{member.mobileNumber}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{formatCurrency(member.dailyAmount)}</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>-</TableCell>
                      <TableCell>
                        <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">
                          Pending
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-1">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-primary-600 h-8 px-2"
                            onClick={() => handleMarkAsPaid(member.id)}
                          >
                            Mark Paid
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="text-red-600 h-8 px-2"
                            onClick={() => handleMarkAsNotPaid(member.id)}
                          >
                            Skip
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
          
          {/* Pagination */}
          {(paginatedPayments.length > 0 || unpaidMembers.length > 0) && totalPages > 1 && (
            <div className="px-5 py-3 flex items-center justify-between border-t border-gray-200">
              <div className="text-sm text-gray-500">
                Showing page {currentPage} of {totalPages}
              </div>
              <div className="flex space-x-1">
                <Button
                  variant="outline"
                  size="sm"
                  className="px-2 py-1 text-sm"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                >
                  Previous
                </Button>
                {Array.from({ length: Math.min(totalPages, 3) }).map((_, i) => (
                  <Button
                    key={i}
                    variant={currentPage === i + 1 ? "secondary" : "outline"}
                    size="sm"
                    className="px-2 py-1 text-sm"
                    onClick={() => setCurrentPage(i + 1)}
                  >
                    {i + 1}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  className="px-2 py-1 text-sm"
                  disabled={currentPage === totalPages || totalPages === 0}
                  onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Payment Modal */}
      {showPaymentModal && (
        <PaymentCollectionModal
          isOpen={showPaymentModal}
          onClose={closePaymentModal}
          initialMemberId={selectedMemberId || undefined}
        />
      )}
    </div>
  );
}
