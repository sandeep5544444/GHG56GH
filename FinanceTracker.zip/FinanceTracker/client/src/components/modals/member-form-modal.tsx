import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, Save, AlertTriangle } from "lucide-react";
import { Member, insertMemberSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, generateSerialNumber } from "@/lib/utils";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

interface MemberFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  member?: Member;
  mode: "create" | "edit";
}

// Create a modified form schema
const formSchema = z.object({
  serialNumber: z.string().min(1, "Serial number is required"),
  name: z.string().min(1, "Name is required"),
  mobileNumber: z.string().min(10, "Mobile number must be at least 10 digits"),
  address: z.string().optional(),
  loanAmount: z.number().min(1, "Loan amount is required"),
  dailyAmount: z.number().min(1, "Daily amount is required"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().optional(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true)
});

type FormValues = z.infer<typeof formSchema>;

export default function MemberFormModal({
  isOpen,
  onClose,
  member,
  mode
}: MemberFormModalProps) {
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const { toast } = useToast();

  // Set up form with validation
  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors }
  } = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      serialNumber: "",
      name: "",
      mobileNumber: "",
      address: "",
      loanAmount: 0,
      dailyAmount: 0,
      startDate: new Date().toISOString().split('T')[0],
      endDate: "",
      notes: "",
      isActive: true
    }
  });

  // Set form values when member data is available for editing
  useEffect(() => {
    if (mode === "edit" && member) {
      // Format dates to YYYY-MM-DD
      const startDate = member.startDate 
        ? new Date(member.startDate).toISOString().split('T')[0]
        : "";
      
      const endDate = member.endDate
        ? new Date(member.endDate).toISOString().split('T')[0]
        : "";
      
      setValue("serialNumber", member.serialNumber);
      setValue("name", member.name);
      setValue("mobileNumber", member.mobileNumber);
      setValue("address", member.address || "");
      setValue("loanAmount", member.loanAmount);
      setValue("dailyAmount", member.dailyAmount);
      setValue("startDate", startDate);
      setValue("endDate", endDate);
      setValue("notes", member.notes || "");
      setValue("isActive", member.isActive === true);
    } else if (mode === "create") {
      // Generate new serial number for new members
      setValue("serialNumber", generateSerialNumber());
      // We don't auto-set dates for new members anymore
    }
  }, [mode, member, setValue, isOpen]);

  const onSubmit = async (data: FormValues) => {
    setSubmitting(true);
    setErrorMessage("");
    try {
      if (mode === "create") {
        // Create new member
        const memberData = {
          ...data,
          startDate: new Date(data.startDate), // Convert string to Date object
          endDate: data.endDate ? new Date(data.endDate) : undefined, // Convert string to Date if exists
          pending: data.loanAmount
        };
        
        const response = await apiRequest('POST', '/api/members', memberData);
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to create member");
        }
        
        toast({
          title: "Success",
          description: "Member created successfully",
          variant: "default"
        });
        
      } else if (mode === "edit" && member) {
        // Update existing member
        const memberData = {
          ...data,
          startDate: new Date(data.startDate), // Convert string to Date object
          endDate: data.endDate ? new Date(data.endDate) : undefined // Convert string to Date if exists
        };
        
        const response = await apiRequest('PUT', `/api/members/${member.id}`, memberData);
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to update member");
        }
        
        toast({
          title: "Success",
          description: "Member updated successfully",
          variant: "default"
        });
      }
      
      // Invalidate related queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/members'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      
      // Reset form and close modal
      resetForm();
      onClose();
    } catch (error) {
      console.error(error);
      const message = error instanceof Error ? error.message : "Failed to save member";
      setErrorMessage(message);
      toast({
        title: "Error",
        description: message,
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    reset();
    setErrorMessage("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) {
        resetForm();
        onClose();
      }
    }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium">
            {mode === "create" ? "Add New Member" : "Edit Member"}
          </DialogTitle>
          <DialogDescription>
            {mode === "create" 
              ? "Enter member details to create a new record"
              : "Update member information"
            }
          </DialogDescription>
        </DialogHeader>
        
        {errorMessage && (
          <div className="bg-red-50 text-red-700 p-3 rounded-md flex items-center gap-2 text-sm">
            <AlertTriangle className="h-4 w-4" />
            {errorMessage}
          </div>
        )}
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="serialNumber">Serial Number<span className="text-red-500">*</span></Label>
              <Input 
                id="serialNumber"
                {...register("serialNumber")}
                className={errors.serialNumber ? "border-red-500" : ""}
                readOnly={mode === "edit"}
              />
              {errors.serialNumber && (
                <p className="text-red-500 text-xs mt-1">{errors.serialNumber.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="name">Full Name<span className="text-red-500">*</span></Label>
              <Input 
                id="name"
                {...register("name")}
                className={errors.name ? "border-red-500" : ""}
              />
              {errors.name && (
                <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="mobileNumber">Mobile Number<span className="text-red-500">*</span></Label>
              <Input 
                id="mobileNumber"
                {...register("mobileNumber")}
                className={errors.mobileNumber ? "border-red-500" : ""}
              />
              {errors.mobileNumber && (
                <p className="text-red-500 text-xs mt-1">{errors.mobileNumber.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="address">Address</Label>
              <Input 
                id="address"
                {...register("address")}
              />
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="loanAmount">Loan Amount<span className="text-red-500">*</span></Label>
              <Input 
                id="loanAmount"
                type="number"
                {...register("loanAmount", { valueAsNumber: true })}
                className={`text-right ${errors.loanAmount ? "border-red-500" : ""}`}
              />
              {errors.loanAmount && (
                <p className="text-red-500 text-xs mt-1">{errors.loanAmount.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="dailyAmount">Daily Payment Amount<span className="text-red-500">*</span></Label>
              <Input 
                id="dailyAmount"
                type="number"
                {...register("dailyAmount", { valueAsNumber: true })}
                className={`text-right ${errors.dailyAmount ? "border-red-500" : ""}`}
              />
              {errors.dailyAmount && (
                <p className="text-red-500 text-xs mt-1">{errors.dailyAmount.message}</p>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="startDate">Start Date<span className="text-red-500">*</span></Label>
              <Input 
                id="startDate"
                type="date"
                {...register("startDate")}
                className={errors.startDate ? "border-red-500" : ""}
              />
              {errors.startDate && (
                <p className="text-red-500 text-xs mt-1">{errors.startDate.message}</p>
              )}
            </div>
            
            <div>
              <Label htmlFor="endDate">End Date</Label>
              <Input 
                id="endDate"
                type="date"
                {...register("endDate")}
              />
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Label htmlFor="isActive" className="flex items-center gap-2 cursor-pointer">
              <input 
                type="checkbox"
                id="isActive"
                className="w-4 h-4"
                {...register("isActive")}
              />
              <span>Active Member</span>
            </Label>
          </div>
          
          <div>
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea 
              id="notes"
              rows={2}
              placeholder="Add any additional notes"
              {...register("notes")}
            />
          </div>
          
          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              className="border-gray-300 hover:bg-gray-100 text-gray-700"
              onClick={() => {
                resetForm();
                onClose();
              }}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={submitting}
              className={`flex items-center gap-2 ${mode === "create" 
                ? "bg-green-600 hover:bg-green-700" 
                : "bg-blue-600 hover:bg-blue-700"} text-white`}
            >
              {submitting ? (
                <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : mode === "create" ? (
                <UserPlus className="h-4 w-4" />
              ) : (
                <Save className="h-4 w-4" />
              )}
              {submitting ? "Processing..." : mode === "create" ? "Create Member" : "Update Member"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}