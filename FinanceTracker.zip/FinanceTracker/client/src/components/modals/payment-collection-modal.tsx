import { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Search, Check, DollarSign, AlertTriangle } from "lucide-react";
import { Member, insertPaymentSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, formatDate } from "@/lib/utils";

interface PaymentCollectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMemberId?: number | null;
}

export default function PaymentCollectionModal({ 
  isOpen, 
  onClose,
  initialMemberId 
}: PaymentCollectionModalProps) {
  const [serialNumber, setSerialNumber] = useState("");
  const [searching, setSearching] = useState(false);
  const [member, setMember] = useState<Member | null>(null);
  const [amountPaid, setAmountPaid] = useState("");
  const [advanceAmount, setAdvanceAmount] = useState("");
  const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  
  const { toast } = useToast();

  // Initialize component with member ID if provided
  useEffect(() => {
    if (initialMemberId) {
      fetchMemberById(initialMemberId);
    }
  }, [initialMemberId]);

  // Set default amount paid when member is loaded
  useEffect(() => {
    if (member) {
      setAmountPaid(member.dailyAmount.toString());
    }
  }, [member]);

  const fetchMemberBySerial = async () => {
    if (!serialNumber) {
      setErrorMessage("Please enter a serial number");
      return;
    }
    
    setSearching(true);
    setErrorMessage("");
    try {
      const response = await fetch(`/api/members/serial/${serialNumber}`);
      if (!response.ok) {
        throw new Error("Member not found");
      }
      
      const memberData = await response.json();
      setMember(memberData);
      setAmountPaid(memberData.dailyAmount.toString());
    } catch (error) {
      setErrorMessage("Member not found with the provided serial number");
      toast({
        title: "Error",
        description: "Member not found with the provided serial number",
        variant: "destructive"
      });
      setMember(null);
    } finally {
      setSearching(false);
    }
  };

  const fetchMemberById = async (id: number | null) => {
    if (id === null) return;
    
    setSearching(true);
    setErrorMessage("");
    try {
      const response = await fetch(`/api/members/${id}`);
      if (!response.ok) {
        throw new Error("Member not found");
      }
      
      const memberData = await response.json();
      setMember(memberData);
      setSerialNumber(memberData.serialNumber);
      setAmountPaid(memberData.dailyAmount.toString());
    } catch (error) {
      setErrorMessage("Member not found");
      toast({
        title: "Error",
        description: "Member not found",
        variant: "destructive"
      });
      setMember(null);
    } finally {
      setSearching(false);
    }
  };

  const handleSearchKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      fetchMemberBySerial();
    }
  };

  const handleSubmit = async () => {
    if (!member) return;
    
    setSubmitting(true);
    setErrorMessage("");
    try {
      // Validate form data
      if (!amountPaid) {
        throw new Error("Please enter the amount paid");
      }
      
      const amount = parseInt(amountPaid, 10);
      const advance = advanceAmount ? parseInt(advanceAmount, 10) : 0;
      
      if (isNaN(amount) || amount < 0) {
        throw new Error("Please enter a valid amount");
      }
      
      if (isNaN(advance) || advance < 0) {
        throw new Error("Please enter a valid advance amount");
      }
      
      if (!paymentDate) {
        throw new Error("Please select a payment date");
      }
      
      const paymentData = {
        memberId: member.id,
        amount,
        advanceAmount: advance > 0 ? advance : undefined,
        paymentDate, // Send as string, backend will convert
        notes,
        isPaid: true
      };
      
      // Submit payment
      await apiRequest('POST', '/api/payments', paymentData);
      
      // Invalidate related queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/payments'] });
      queryClient.invalidateQueries({ queryKey: ['/api/payments/date'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      queryClient.invalidateQueries({ queryKey: ['/api/members'] });
      
      toast({
        title: "Success",
        description: "Payment recorded successfully",
        variant: "default"
      });
      
      // Reset form and close modal
      resetForm();
      onClose();
    } catch (error) {
      console.error(error);
      const message = error instanceof Error ? error.message : "Failed to record payment";
      setErrorMessage(message);
      toast({
        title: "Error",
        description: message,
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const resetForm = () => {
    setSerialNumber("");
    setMember(null);
    setAmountPaid("");
    setAdvanceAmount("");
    setPaymentDate(new Date().toISOString().split('T')[0]);
    setNotes("");
    setErrorMessage("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) {
        resetForm();
        onClose();
      }
    }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-medium">Payment Collection</DialogTitle>
          <DialogDescription>
            Record a new payment for a member
          </DialogDescription>
        </DialogHeader>
        
        {errorMessage && (
          <div className="bg-red-50 text-red-700 p-3 rounded-md flex items-center gap-2 text-sm">
            <AlertTriangle className="h-4 w-4" />
            {errorMessage}
          </div>
        )}
        
        {/* Search Bar */}
        <div className="mb-4">
          <Label htmlFor="serialSearch" className="mb-1 block">Search Member</Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input 
              id="serialSearch"
              type="text" 
              placeholder="Enter serial number (e.g. DL-1043)" 
              className="w-full pl-10 pr-4 py-2"
              value={serialNumber}
              onChange={(e) => setSerialNumber(e.target.value)}
              onKeyPress={handleSearchKeyPress}
              disabled={searching || !!initialMemberId}
            />
            <Button 
              variant="secondary" 
              size="sm" 
              className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8"
              onClick={fetchMemberBySerial}
              disabled={searching || !serialNumber || !!initialMemberId}
            >
              Search
            </Button>
          </div>
        </div>
        
        {/* Member Information */}
        {member && (
          <div className="bg-blue-50 p-4 rounded-lg mb-4 border border-blue-100">
            <div className="flex justify-between items-start">
              <div>
                <h4 className="font-medium text-gray-800">{member.name}</h4>
                <p className="text-sm text-gray-500">{member.mobileNumber}</p>
                <p className="text-sm text-gray-500">Serial No: {member.serialNumber}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-500">Daily Amount</p>
                <p className="font-semibold text-gray-800">{formatCurrency(member.dailyAmount)}</p>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <div>
                <p className="text-xs text-gray-500">Pending Amount</p>
                <p className="font-medium text-red-600">{formatCurrency(member.pending)}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500">Last Paid Date</p>
                <p className="font-medium text-gray-700">
                  {member.lastPaidDate ? formatDate(member.lastPaidDate) : 'Never'}
                </p>
              </div>
            </div>
          </div>
        )}
        
        {/* Payment Form */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="amountPaid">Amount Paid Today<span className="text-red-500">*</span></Label>
            <Input 
              id="amountPaid"
              type="number" 
              value={amountPaid}
              onChange={(e) => setAmountPaid(e.target.value)}
              disabled={!member}
              className="text-right"
            />
          </div>
          
          <div>
            <Label htmlFor="advanceAmount">Advance Amount (Optional)</Label>
            <Input 
              id="advanceAmount"
              type="number" 
              placeholder="0"
              value={advanceAmount}
              onChange={(e) => setAdvanceAmount(e.target.value)}
              disabled={!member}
              className="text-right"
            />
          </div>
          
          <div>
            <Label htmlFor="paymentDate">Payment Date<span className="text-red-500">*</span></Label>
            <Input 
              id="paymentDate"
              type="date" 
              value={paymentDate}
              onChange={(e) => setPaymentDate(e.target.value)}
              disabled={!member}
            />
          </div>
          
          <div>
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea 
              id="notes"
              rows={2}
              placeholder="Add any additional notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              disabled={!member}
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            type="button" 
            variant="outline" 
            className="border-gray-300 hover:bg-gray-100 text-gray-700"
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button 
            type="button" 
            onClick={handleSubmit}
            disabled={!member || submitting}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
          >
            {submitting ? (
              <div className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <DollarSign className="h-4 w-4" />
            )}
            {submitting ? "Processing..." : "Record Payment"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
