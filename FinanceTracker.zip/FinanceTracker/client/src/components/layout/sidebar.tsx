import { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

// Icons
import {
  LayoutDashboard,
  Users,
  DollarSign,
  BarChart2,
  Settings,
  X
} from "lucide-react";

interface SidebarProps {
  showMobileMenu: boolean;
  closeMobileMenu: () => void;
}

interface SidebarLinkProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
  onClick?: () => void;
}

const SidebarLink = ({ href, icon, label, active, onClick }: SidebarLinkProps) => {
  return (
    <Link href={href}>
      <a
        className={cn(
          "flex items-center space-x-3 p-3 rounded-lg",
          active 
            ? "bg-primary-50 text-primary-600" 
            : "text-gray-700 hover:bg-gray-50"
        )}
        onClick={onClick}
      >
        {icon}
        <span>{label}</span>
      </a>
    </Link>
  );
};

export default function Sidebar({ showMobileMenu, closeMobileMenu }: SidebarProps) {
  const [location] = useLocation();

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex md:flex-col w-64 bg-white shadow-md">
        <div className="p-4 border-b">
          <h1 className="text-xl font-semibold text-primary-600">Daily Finance</h1>
        </div>
        <nav className="flex-1 overflow-y-auto p-4 space-y-1 scrollbar-hide">
          <SidebarLink 
            href="/" 
            icon={<LayoutDashboard className="h-5 w-5" />} 
            label="Dashboard" 
            active={location === "/"} 
          />
          <SidebarLink 
            href="/members" 
            icon={<Users className="h-5 w-5" />} 
            label="Members" 
            active={location === "/members"} 
          />
          <SidebarLink 
            href="/payments" 
            icon={<DollarSign className="h-5 w-5" />} 
            label="Payments" 
            active={location === "/payments"} 
          />
          <SidebarLink 
            href="/reports" 
            icon={<BarChart2 className="h-5 w-5" />} 
            label="Reports" 
            active={location === "/reports"} 
          />
          <SidebarLink 
            href="/settings" 
            icon={<Settings className="h-5 w-5" />} 
            label="Settings" 
            active={location === "/settings"} 
          />
        </nav>
        <div className="p-4 border-t">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-600">
              <span>AU</span>
            </div>
            <div>
              <h3 className="font-medium">Admin User</h3>
              <p className="text-sm text-gray-500">admin@example.com</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Sidebar */}
      {showMobileMenu && (
        <div className="md:hidden fixed inset-0 z-50 bg-black bg-opacity-50">
          <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-lg z-50 flex flex-col">
            <div className="p-4 border-b flex justify-between items-center">
              <h1 className="text-xl font-semibold text-primary-600">Daily Finance</h1>
              <button
                onClick={closeMobileMenu}
                className="p-1 rounded-full hover:bg-gray-100"
              >
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto p-4 space-y-1">
              <SidebarLink 
                href="/" 
                icon={<LayoutDashboard className="h-5 w-5" />} 
                label="Dashboard" 
                active={location === "/"} 
                onClick={closeMobileMenu}
              />
              <SidebarLink 
                href="/members" 
                icon={<Users className="h-5 w-5" />} 
                label="Members" 
                active={location === "/members"} 
                onClick={closeMobileMenu}
              />
              <SidebarLink 
                href="/payments" 
                icon={<DollarSign className="h-5 w-5" />} 
                label="Payments" 
                active={location === "/payments"} 
                onClick={closeMobileMenu}
              />
              <SidebarLink 
                href="/reports" 
                icon={<BarChart2 className="h-5 w-5" />} 
                label="Reports" 
                active={location === "/reports"} 
                onClick={closeMobileMenu}
              />
              <SidebarLink 
                href="/settings" 
                icon={<Settings className="h-5 w-5" />} 
                label="Settings" 
                active={location === "/settings"} 
                onClick={closeMobileMenu}
              />
            </nav>
            <div className="p-4 border-t">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-full bg-primary-100 flex items-center justify-center text-primary-600">
                  <span>AU</span>
                </div>
                <div>
                  <h3 className="font-medium">Admin User</h3>
                  <p className="text-sm text-gray-500">admin@example.com</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
