import { useLocation, Link } from "wouter";
import {
  LayoutDashboard,
  Users,
  DollarSign,
  BarChart2
} from "lucide-react";
import { cn } from "@/lib/utils";

interface MobileNavLinkProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
}

const MobileNavLink = ({ href, icon, label, active }: MobileNavLinkProps) => {
  return (
    <Link href={href}>
      <a className={cn(
        "flex flex-col items-center py-2",
        active ? "text-primary-600" : "text-gray-500"
      )}>
        {icon}
        <span className="text-xs mt-1">{label}</span>
      </a>
    </Link>
  );
};

export default function MobileNav() {
  const [location] = useLocation();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg z-10">
      <div className="flex justify-around">
        <MobileNavLink 
          href="/" 
          icon={<LayoutDashboard className="h-5 w-5" />}
          label="Dashboard"
          active={location === "/"}
        />
        <MobileNavLink 
          href="/members" 
          icon={<Users className="h-5 w-5" />}
          label="Members"
          active={location === "/members"}
        />
        <MobileNavLink 
          href="/payments" 
          icon={<DollarSign className="h-5 w-5" />}
          label="Payments"
          active={location === "/payments"}
        />
        <MobileNavLink 
          href="/reports" 
          icon={<BarChart2 className="h-5 w-5" />}
          label="Reports"
          active={location === "/reports"}
        />
      </div>
    </nav>
  );
}
