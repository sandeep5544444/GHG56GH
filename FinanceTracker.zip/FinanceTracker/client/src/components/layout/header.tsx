import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Search, Menu, Bell } from "lucide-react";
import PaymentCollectionModal from "@/components/modals/payment-collection-modal";
import { debounce } from "@/lib/utils";
import { useSearchContext } from "@/context/app-context";

interface HeaderProps {
  toggleMobileMenu: () => void;
}

export default function Header({ toggleMobileMenu }: HeaderProps) {
  const [showPaymentCollection, setShowPaymentCollection] = useState(false);
  const { searchQuery, setSearchQuery } = useSearchContext();
  const { toast } = useToast();

  const handleSearch = debounce((value: string) => {
    setSearchQuery(value);
  }, 300);

  const handlePaymentCollectionOpen = () => {
    setShowPaymentCollection(true);
  };

  const handlePaymentCollectionClose = () => {
    setShowPaymentCollection(false);
  };

  const handleNotificationClick = () => {
    toast({
      title: "Notifications",
      description: "Notification feature coming soon!",
    });
  };

  return (
    <>
      <header className="bg-white shadow-sm sticky top-0 z-10">
        <div className="px-4 py-3 flex items-center justify-between md:justify-end">
          {/* Menu button for mobile */}
          <button 
            className="md:hidden text-gray-500 hover:text-gray-700"
            onClick={toggleMobileMenu}
          >
            <Menu className="h-6 w-6" />
          </button>
          
          {/* Global Search */}
          <div className="flex-1 max-w-lg mx-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input 
                type="text" 
                placeholder="Search by name, mobile, or serial no." 
                className="w-full pl-10 pr-4 py-2"
                defaultValue={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
              />
            </div>
          </div>
          
          {/* Action buttons */}
          <div className="flex space-x-2">
            <Button 
              onClick={handlePaymentCollectionOpen}
              className="flex items-center"
            >
              <DollarSign className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Payment Collection</span>
            </Button>
            <Button 
              variant="ghost" 
              className="p-2 rounded-lg text-gray-500 hover:bg-gray-100"
              onClick={handleNotificationClick}
            >
              <Bell className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Payment Collection Modal */}
      <PaymentCollectionModal 
        isOpen={showPaymentCollection} 
        onClose={handlePaymentCollectionClose} 
      />
    </>
  );
}

// Dollar sign icon component since it's not directly available from lucide
function DollarSign({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <line x1="12" y1="1" x2="12" y2="23"></line>
      <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
    </svg>
  );
}
