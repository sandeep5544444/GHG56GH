import { cn, formatCurrency } from "@/lib/utils";
import { ReactNode } from "react";

interface SummaryCardProps {
  title: string;
  amount: number;
  subtitle?: string;
  subtitleAmount?: number;
  icon: ReactNode;
  borderColor: string;
  iconBgColor: string;
  iconColor: string;
  linkText?: string;
  linkUrl?: string;
  loading?: boolean;
}

export default function SummaryCard({
  title,
  amount,
  subtitle,
  subtitleAmount,
  icon,
  borderColor,
  iconBgColor,
  iconColor,
  linkText,
  linkUrl,
  loading = false
}: SummaryCardProps) {
  return (
    <div className={cn("bg-white rounded-lg shadow p-5 border-l-4", borderColor)}>
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-sm font-medium text-gray-500">{title}</h3>
          <div className="flex items-baseline mt-1">
            {loading ? (
              <div className="h-8 w-28 bg-gray-200 animate-pulse rounded"></div>
            ) : (
              <h2 className="text-2xl font-semibold text-gray-800">
                {formatCurrency(amount)}
              </h2>
            )}
            {subtitle && (
              <span className="ml-2 text-sm font-medium text-gray-500">
                {subtitle}
              </span>
            )}
          </div>
          {(subtitle || subtitleAmount !== undefined) && (
            <div className="mt-1 text-sm">
              {loading ? (
                <div className="h-4 w-24 bg-gray-200 animate-pulse rounded"></div>
              ) : (
                <>
                  <span className={cn("font-medium", subtitle?.includes("unpaid") ? "text-red-500" : "text-green-500")}>
                    {subtitle}
                  </span>
                  {subtitleAmount !== undefined && (
                    <span className="text-gray-500 ml-1">
                      ({formatCurrency(subtitleAmount)})
                    </span>
                  )}
                </>
              )}
            </div>
          )}
        </div>
        <div className={cn("p-2 rounded-full", iconBgColor, iconColor)}>
          {icon}
        </div>
      </div>
      {linkText && linkUrl && (
        <div className="mt-3 pt-3 border-t border-gray-100">
          <a 
            href={linkUrl} 
            className={cn("text-sm font-medium hover:underline", 
              borderColor === "border-primary-500" ? "text-primary-600 hover:text-primary-700" : 
              borderColor === "border-secondary-500" ? "text-secondary-500 hover:text-green-700" :
              borderColor === "border-accent-500" ? "text-accent-500 hover:text-orange-700" :
              "text-indigo-600 hover:text-indigo-700"
            )}
          >
            {linkText} →
          </a>
        </div>
      )}
    </div>
  );
}
