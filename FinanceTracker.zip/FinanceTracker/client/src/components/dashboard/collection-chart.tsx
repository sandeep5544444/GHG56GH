import { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download } from "lucide-react";
import { formatCurrency } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

interface CollectionData {
  name: string;
  amount: number;
  target: number;
}

interface CollectionChartProps {
  data?: CollectionData[];
  loading?: boolean;
}

export default function CollectionChart({ data, loading = false }: CollectionChartProps) {
  const [period, setPeriod] = useState("weekly");
  const [chartData, setChartData] = useState<CollectionData[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (!data || data.length === 0) {
      // Generate some placeholder data if none is provided
      const weeklyData: CollectionData[] = [
        { name: "Mon", amount: 24500, target: 30000 },
        { name: "Tue", amount: 21500, target: 30000 },
        { name: "Wed", amount: 28500, target: 30000 },
        { name: "Thu", amount: 15500, target: 30000 },
        { name: "Fri", amount: 32500, target: 30000 },
        { name: "Sat", amount: 24500, target: 30000 },
        { name: "Sun", amount: 20500, target: 30000 },
      ];

      const monthlyData: CollectionData[] = [
        { name: "Jan", amount: 745000, target: 800000 },
        { name: "Feb", amount: 680000, target: 800000 },
        { name: "Mar", amount: 810000, target: 800000 },
        { name: "Apr", amount: 755000, target: 800000 },
        { name: "May", amount: 840000, target: 800000 },
        { name: "Jun", amount: 750000, target: 800000 },
      ];

      const dailyData: CollectionData[] = [
        { name: "Day 1", amount: 24500, target: 30000 },
        { name: "Day 2", amount: 27800, target: 30000 },
        { name: "Day 3", amount: 29100, target: 30000 },
        { name: "Day 4", amount: 28600, target: 30000 },
        { name: "Day 5", amount: 22000, target: 30000 },
      ];

      if (period === "weekly") {
        setChartData(weeklyData);
      } else if (period === "monthly") {
        setChartData(monthlyData);
      } else {
        setChartData(dailyData);
      }
    } else {
      setChartData(data);
    }
  }, [data, period]);

  const handleExport = () => {
    toast({
      title: "Export Started",
      description: "Your data export is being prepared",
    });
  };

  const handlePeriodChange = (value: string) => {
    setPeriod(value);
  };

  // Calculate totals
  const totalAmount = chartData.reduce((sum, item) => sum + item.amount, 0);
  const totalTarget = chartData.reduce((sum, item) => sum + item.target, 0);
  const collectionRate = totalTarget > 0 ? Math.round((totalAmount / totalTarget) * 100) : 0;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-semibold">Collection Trend</CardTitle>
        <div className="flex space-x-2">
          <Select value={period} onValueChange={handlePeriodChange}>
            <SelectTrigger className="w-24 h-8 text-xs">
              <SelectValue placeholder="Period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            variant="outline" 
            size="sm" 
            className="h-8 px-2 text-xs"
            onClick={handleExport}
          >
            <Download className="mr-1 h-3 w-3" />
            Export
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-48 bg-gray-50 rounded-lg flex items-center justify-center animate-pulse">
            Loading chart data...
          </div>
        ) : (
          <>
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={chartData}
                  margin={{ top: 10, right: 10, left: -25, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis 
                    tick={{ fontSize: 12 }} 
                    tickFormatter={(value) => formatCurrency(value).replace('₹', '')}
                  />
                  <Tooltip 
                    formatter={(value: number) => [formatCurrency(value), 'Amount']}
                    labelFormatter={(label) => `${label}`}
                  />
                  <Legend wrapperStyle={{ fontSize: '12px' }} />
                  <Bar 
                    dataKey="amount" 
                    name="Collected" 
                    fill="#3b82f6" 
                    radius={[4, 4, 0, 0]} 
                  />
                  <Bar 
                    dataKey="target" 
                    name="Target" 
                    fill="#93c5fd" 
                    radius={[4, 4, 0, 0]} 
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-between text-sm text-gray-500 mt-4">
              <span>Collection Rate: {collectionRate}%</span>
              <span>Total This Period: {formatCurrency(totalAmount)}</span>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
