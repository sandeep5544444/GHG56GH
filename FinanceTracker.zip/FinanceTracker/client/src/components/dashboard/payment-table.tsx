import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Payment, Member } from "@shared/schema";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download } from "lucide-react";
import { formatCurrency, formatDateTime, getInitials, getRandomColor } from "@/lib/utils";
import { useSearchContext } from "@/context/app-context";
import PaymentCollectionModal from "@/components/modals/payment-collection-modal";

interface PaymentWithMember extends Payment {
  member?: Member;
}

interface PaymentTableProps {
  payments?: PaymentWithMember[];
  loading?: boolean;
}

export default function PaymentTable({ payments = [], loading = false }: PaymentTableProps) {
  const [filter, setFilter] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedMemberId, setSelectedMemberId] = useState<number | null>(null);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const { toast } = useToast();
  
  const itemsPerPage = 5;
  const { searchQuery } = useSearchContext();
  
  const handleFilterChange = (value: string) => {
    setFilter(value);
    setCurrentPage(1);
  };
  
  const handleExport = () => {
    toast({
      title: "Export Started",
      description: "Your payment data export is being prepared",
    });
  };
  
  const handleViewPayment = (payment: PaymentWithMember) => {
    toast({
      title: "Payment Details",
      description: `Viewing payment for ${payment.member?.name || 'Unknown'} of ${formatCurrency(payment.amount)}`,
    });
  };
  
  const handleCollectPayment = (payment: PaymentWithMember) => {
    if (payment.member) {
      setSelectedMemberId(payment.member.id);
      setShowPaymentModal(true);
    }
  };
  
  const closePaymentModal = () => {
    setShowPaymentModal(false);
    setSelectedMemberId(null);
  };
  
  // Filter payments based on selected filter and search query
  const filteredPayments = payments.filter(payment => {
    const matchesFilter = 
      filter === "all" ||
      (filter === "received" && payment.isPaid) ||
      (filter === "pending" && !payment.isPaid);
      
    const matchesSearch = !searchQuery || 
      (payment.member && (
        payment.member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        payment.member.mobileNumber.includes(searchQuery) ||
        payment.member.serialNumber.toLowerCase().includes(searchQuery.toLowerCase())
      ));
      
    return matchesFilter && matchesSearch;
  });
  
  // Pagination
  const totalPages = Math.ceil(filteredPayments.length / itemsPerPage);
  const paginatedPayments = filteredPayments.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  // Sample data for development/demo (if no payments provided)
  const samplePayments: PaymentWithMember[] = [
    {
      id: 1,
      memberId: 1,
      amount: 500,
      advanceAmount: 0,
      paymentDate: new Date(),
      notes: "Regular payment",
      isPaid: true,
      createdAt: new Date(),
      member: {
        id: 1,
        serialNumber: "DL-1043",
        name: "Rahul Kumar",
        mobileNumber: "9876543210",
        loanAmount: 15000,
        dailyAmount: 500,
        startDate: new Date(),
        totalPaid: 8000,
        pending: 7000,
        lastPaidDate: new Date(),
        createdAt: new Date(),
        isActive: true
      }
    },
    {
      id: 2,
      memberId: 2,
      amount: 500,
      advanceAmount: 500,
      paymentDate: new Date(),
      notes: "Paid with advance",
      isPaid: true,
      createdAt: new Date(),
      member: {
        id: 2,
        serialNumber: "DL-0872",
        name: "Sunita Patel",
        mobileNumber: "8765432109",
        loanAmount: 20000,
        dailyAmount: 500,
        startDate: new Date(),
        totalPaid: 12000,
        pending: 8000,
        lastPaidDate: new Date(),
        createdAt: new Date(),
        isActive: true
      }
    },
    {
      id: 3,
      memberId: 3,
      amount: 0,
      advanceAmount: 0,
      paymentDate: new Date(),
      isPaid: false,
      createdAt: new Date(),
      member: {
        id: 3,
        serialNumber: "DL-1356",
        name: "Anil Mehta",
        mobileNumber: "7654321098",
        loanAmount: 10000,
        dailyAmount: 500,
        startDate: new Date(),
        totalPaid: 2000,
        pending: 8000,
        lastPaidDate: new Date(Date.now() - 86400000 * 3), // 3 days ago
        createdAt: new Date(),
        isActive: true
      }
    },
    {
      id: 4,
      memberId: 4,
      amount: 0,
      advanceAmount: 0,
      paymentDate: new Date(),
      isPaid: false,
      createdAt: new Date(),
      member: {
        id: 4,
        serialNumber: "DL-0945",
        name: "Neha Sharma",
        mobileNumber: "6543210987",
        loanAmount: 15000,
        dailyAmount: 700,
        startDate: new Date(),
        totalPaid: 5000,
        pending: 10000,
        lastPaidDate: new Date(Date.now() - 86400000 * 2), // 2 days ago
        createdAt: new Date(),
        isActive: true
      }
    },
    {
      id: 5,
      memberId: 5,
      amount: 300,
      advanceAmount: 0,
      paymentDate: new Date(),
      notes: "Regular payment",
      isPaid: true,
      createdAt: new Date(),
      member: {
        id: 5,
        serialNumber: "DL-0578",
        name: "Vijay Gupta",
        mobileNumber: "5432109876",
        loanAmount: 8000,
        dailyAmount: 300,
        startDate: new Date(),
        totalPaid: 3000,
        pending: 5000,
        lastPaidDate: new Date(),
        createdAt: new Date(),
        isActive: true
      }
    }
  ];
  
  // Use sample data if no payments provided
  const displayPayments = paginatedPayments.length > 0 ? paginatedPayments : 
    (payments.length === 0 ? samplePayments : []);
  
  return (
    <>
      <Card className="overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-base font-semibold">Recent Payment Activity</CardTitle>
          <div className="flex space-x-2">
            <Select value={filter} onValueChange={handleFilterChange}>
              <SelectTrigger className="w-36 h-8 text-xs">
                <SelectValue placeholder="Filter payments" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Payments</SelectItem>
                <SelectItem value="received">Received</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              variant="outline" 
              size="sm"
              className="h-8 px-2 text-xs"
              onClick={handleExport}
            >
              <Download className="mr-1 h-3 w-3" />
              Export
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gray-50">
                  <TableHead className="font-medium text-xs">Serial No.</TableHead>
                  <TableHead className="font-medium text-xs">Member</TableHead>
                  <TableHead className="font-medium text-xs">Amount</TableHead>
                  <TableHead className="font-medium text-xs">Date</TableHead>
                  <TableHead className="font-medium text-xs">Status</TableHead>
                  <TableHead className="font-medium text-xs">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  Array(5).fill(0).map((_, index) => (
                    <TableRow key={index}>
                      <TableCell className="animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-16"></div>
                      </TableCell>
                      <TableCell className="animate-pulse">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-gray-200"></div>
                          <div className="ml-3">
                            <div className="h-4 bg-gray-200 rounded w-24 mb-1"></div>
                            <div className="h-3 bg-gray-200 rounded w-20"></div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-12 mb-1"></div>
                        <div className="h-3 bg-gray-200 rounded w-20"></div>
                      </TableCell>
                      <TableCell className="animate-pulse">
                        <div className="h-4 bg-gray-200 rounded w-28"></div>
                      </TableCell>
                      <TableCell className="animate-pulse">
                        <div className="h-6 bg-gray-200 rounded w-16"></div>
                      </TableCell>
                      <TableCell className="animate-pulse">
                        <div className="h-6 bg-gray-200 rounded w-14"></div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  displayPayments.map((payment) => (
                    <TableRow key={payment.id} className="hover:bg-gray-50">
                      <TableCell className="text-sm text-gray-900">
                        {payment.member?.serialNumber || '-'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <div className={`h-8 w-8 rounded-full ${getRandomColor()} flex items-center justify-center text-sm font-medium`}>
                            {getInitials(payment.member?.name || 'Unknown')}
                          </div>
                          <div className="ml-3">
                            <div className="text-sm font-medium text-gray-900">{payment.member?.name || 'Unknown'}</div>
                            <div className="text-xs text-gray-500">+{payment.member?.mobileNumber || '-'}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm text-gray-900">
                          {payment.isPaid 
                            ? formatCurrency(payment.amount + (payment.advanceAmount || 0)) 
                            : formatCurrency(0)
                          }
                        </div>
                        <div className="text-xs text-gray-500">
                          {payment.isPaid 
                            ? payment.advanceAmount 
                              ? `Daily: ${formatCurrency(payment.amount)} + ${formatCurrency(payment.advanceAmount)} Advance`
                              : `Daily: ${formatCurrency(payment.amount)}`
                            : `Due: ${formatCurrency(payment.member?.dailyAmount || 0)}`
                          }
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm text-gray-900">
                          {payment.isPaid 
                            ? formatDateTime(payment.paymentDate)
                            : 'Today'
                          }
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                          payment.isPaid
                            ? 'bg-green-100 text-green-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {payment.isPaid ? 'Paid' : 'Pending'}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-6 p-0 text-primary-600 hover:text-primary-900 hover:bg-transparent"
                          onClick={() => payment.isPaid 
                            ? handleViewPayment(payment)
                            : handleCollectPayment(payment)
                          }
                        >
                          {payment.isPaid ? 'View' : 'Collect'}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          <div className="px-5 py-3 flex items-center justify-between border-t border-gray-200">
            <div className="text-sm text-gray-500">
              Showing <span className="font-medium">{displayPayments.length}</span> of{" "}
              <span className="font-medium">{filteredPayments.length}</span> entries
            </div>
            <div className="flex space-x-1">
              <Button
                variant="outline"
                size="sm"
                className="px-2 py-1 text-sm"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              >
                Previous
              </Button>
              {Array.from({ length: Math.min(totalPages, 3) }).map((_, i) => (
                <Button
                  key={i}
                  variant={currentPage === i + 1 ? "secondary" : "outline"}
                  size="sm"
                  className="px-2 py-1 text-sm"
                  onClick={() => setCurrentPage(i + 1)}
                >
                  {i + 1}
                </Button>
              ))}
              <Button
                variant="outline"
                size="sm"
                className="px-2 py-1 text-sm"
                disabled={currentPage === totalPages || totalPages === 0}
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              >
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {showPaymentModal && selectedMemberId && (
        <PaymentCollectionModal
          isOpen={showPaymentModal}
          onClose={closePaymentModal}
          initialMemberId={selectedMemberId}
        />
      )}
    </>
  );
}
