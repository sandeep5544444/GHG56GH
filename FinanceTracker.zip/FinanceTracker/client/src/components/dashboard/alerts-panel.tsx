import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, Clock, CalendarCheck, Info } from "lucide-react";

interface Alert {
  icon: React.ReactNode;
  iconBgColor: string;
  iconColor: string;
  title: string;
  description: string;
  actionText: string;
  action: () => void;
}

interface AlertsPanelProps {
  alerts?: {
    noPayment7Days: number;
    dueForTomorrow: number;
    completingThisWeek: number;
  };
  loading?: boolean;
}

export default function AlertsPanel({ alerts, loading = false }: AlertsPanelProps) {
  const { toast } = useToast();

  const handleViewMembers = () => {
    toast({
      title: "View Members",
      description: "Navigating to members with payment issues",
    });
  };

  const handleSendReminders = () => {
    toast({
      title: "Send Reminders",
      description: "Reminders sent successfully",
    });
  };

  const handleViewDetails = () => {
    toast({
      title: "View Details",
      description: "Showing loans completing this week",
    });
  };

  const handleChangeSchedule = () => {
    toast({
      title: "Backup Schedule",
      description: "Schedule update dialog will open",
    });
  };

  const alertsData: Alert[] = [
    {
      icon: <AlertTriangle className="h-5 w-5" />,
      iconBgColor: "bg-red-100",
      iconColor: "text-red-500",
      title: `${alerts?.noPayment7Days || 15} Members with 7+ Days No Payment`,
      description: "Total pending: ₹45,000",
      actionText: "View Members",
      action: handleViewMembers
    },
    {
      icon: <Clock className="h-5 w-5" />,
      iconBgColor: "bg-yellow-100",
      iconColor: "text-yellow-500",
      title: `${alerts?.dueForTomorrow || 32} Members Due for Payment Tomorrow`,
      description: "Expected amount: ₹16,000",
      actionText: "Send Reminders",
      action: handleSendReminders
    },
    {
      icon: <CalendarCheck className="h-5 w-5" />,
      iconBgColor: "bg-green-100",
      iconColor: "text-green-500",
      title: `${alerts?.completingThisWeek || 8} Loans Completing This Week`,
      description: "Final collection: ₹12,000",
      actionText: "View Details",
      action: handleViewDetails
    },
    {
      icon: <Info className="h-5 w-5" />,
      iconBgColor: "bg-blue-100",
      iconColor: "text-blue-500",
      title: "Weekly Backup Scheduled",
      description: "Next backup: Sunday, 12:00 AM",
      actionText: "Change Schedule",
      action: handleChangeSchedule
    }
  ];

  return (
    <Card className="h-full">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-base font-semibold">Alerts & Reminders</CardTitle>
        <Button variant="ghost" size="sm" className="text-primary-600 text-sm font-medium hover:text-primary-700">
          View All
        </Button>
      </CardHeader>
      <CardContent className="p-0 overflow-y-auto max-h-[320px]">
        {loading ? (
          Array(4).fill(0).map((_, index) => (
            <div key={index} className="p-4 border-b border-gray-100 animate-pulse">
              <div className="flex">
                <div className="w-10 h-10 rounded-full bg-gray-200 mr-3 flex-shrink-0"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-2"></div>
                  <div className="h-6 w-24 bg-gray-200 rounded"></div>
                </div>
              </div>
            </div>
          ))
        ) : (
          alertsData.map((alert, index) => (
            <div key={index} className="p-4 border-b border-gray-100 hover:bg-gray-50 last:border-b-0">
              <div className="flex">
                <div className={`w-10 h-10 rounded-full ${alert.iconBgColor} flex items-center justify-center ${alert.iconColor} mr-3 flex-shrink-0`}>
                  {alert.icon}
                </div>
                <div>
                  <h4 className="text-sm font-medium text-gray-800">{alert.title}</h4>
                  <p className="text-xs text-gray-500 mt-1">{alert.description}</p>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="mt-2 h-6 p-0 text-xs font-medium text-primary-600 hover:text-primary-700 hover:bg-transparent"
                    onClick={alert.action}
                  >
                    {alert.actionText}
                  </Button>
                </div>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
