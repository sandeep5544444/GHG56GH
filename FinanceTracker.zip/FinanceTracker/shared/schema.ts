import { pgTable, text, serial, integer, timestamp, boolean, doublePrecision } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Base user model (for authentication)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email"),
  role: text("role").default("user"),
});

// Member model 
export const members = pgTable("members", {
  id: serial("id").primaryKey(),
  serialNumber: text("serial_number").notNull().unique(),
  name: text("name").notNull(),
  photo: text("photo"),
  friendPhoto: text("friend_photo"),
  mobileNumber: text("mobile_number").notNull(),
  address: text("address"),
  loanAmount: integer("loan_amount").notNull(),
  dailyAmount: integer("daily_amount").notNull(),
  totalPaid: integer("total_paid").default(0),
  pending: integer("pending"),
  lastPaidDate: timestamp("last_paid_date"),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date"),
  notes: text("notes"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Payment model
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  memberId: integer("member_id").notNull(),
  amount: integer("amount").notNull(),
  advanceAmount: integer("advance_amount").default(0),
  paymentDate: timestamp("payment_date").notNull(),
  notes: text("notes"),
  isPaid: boolean("is_paid").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Document model
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  memberId: integer("member_id").notNull(),
  type: text("type").notNull(), // e.g., "aadhar", "pan", "agreement"
  path: text("path").notNull(),
  uploadedAt: timestamp("uploaded_at").defaultNow(),
});

// Backup model
export const backups = pgTable("backups", {
  id: serial("id").primaryKey(),
  path: text("path").notNull(),
  size: integer("size"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Settings model for app configuration
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Create insert schemas for models
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

export const insertMemberSchema = createInsertSchema(members, {
  startDate: z.string().transform(val => new Date(val)),
  endDate: z.string().optional().transform(val => val ? new Date(val) : undefined),
}).omit({
  id: true,
  totalPaid: true,
  createdAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments, {
  paymentDate: z.string().transform(val => new Date(val)),
}).omit({
  id: true,
  createdAt: true,
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  uploadedAt: true,
});

export const insertBackupSchema = createInsertSchema(backups).omit({
  id: true,
  createdAt: true,
});

export const insertSettingSchema = createInsertSchema(settings).omit({
  id: true,
  updatedAt: true,
});

// Type definitions
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertMember = z.infer<typeof insertMemberSchema>;
export type Member = typeof members.$inferSelect;

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

export type InsertBackup = z.infer<typeof insertBackupSchema>;
export type Backup = typeof backups.$inferSelect;

export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type Setting = typeof settings.$inferSelect;

// Extended schemas for frontend validation
export const memberFormSchema = insertMemberSchema.extend({
  mobileNumber: z.string().min(10, "Mobile number must be at least 10 digits"),
  loanAmount: z.number().min(1, "Loan amount is required"),
  dailyAmount: z.number().min(1, "Daily amount is required"),
  startDate: z.string().transform(dateStr => new Date(dateStr)),
  endDate: z.string().optional().transform(dateStr => dateStr ? new Date(dateStr) : undefined),
});

export const paymentFormSchema = insertPaymentSchema.extend({
  amount: z.number().min(0, "Amount must be a positive number"),
  advanceAmount: z.number().optional(),
  paymentDate: z.string().transform(dateStr => new Date(dateStr)),
});
