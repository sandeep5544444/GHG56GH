import { Member, Payment } from '../types';

// Calculate dashboard statistics
export const calculateDashboardStats = (members: Member[], payments: Payment[]) => {
  const today = new Date().toISOString().split('T')[0];
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  // Today's payments
  const todayPayments = payments.filter(p => p.date === today);
  const todayPaid = todayPayments.filter(p => p.status === 'paid');
  const todayUnpaid = todayPayments.filter(p => p.status === 'not_paid');
  
  const todayPaidAmount = todayPaid.reduce((sum, p) => sum + p.amount, 0);
  const todayUnpaidAmount = todayUnpaid.reduce((sum, p) => sum + p.amount, 0);
  
  // Monthly collection
  const monthlyPayments = payments.filter(p => {
    const paymentDate = new Date(p.date);
    return paymentDate.getMonth() === currentMonth && 
           paymentDate.getFullYear() === currentYear &&
           p.status === 'paid';
  });
  
  const monthlyCollection = monthlyPayments.reduce((sum, p) => sum + p.amount, 0);
  
  return {
    totalMembers: members.length,
    todayPaidCount: todayPaid.length,
    todayPaidAmount,
    todayUnpaidCount: todayUnpaid.length,
    todayUnpaidAmount,
    monthlyCollection
  };
};

// Calculate total collected amount for a member
export const calculateTotalPaid = (payments: Payment[]): number => {
  return payments
    .filter(p => p.status === 'paid')
    .reduce((sum, p) => sum + p.amount, 0);
};

// Calculate pending amount for a member
export const calculatePendingAmount = (payments: Payment[], dailyAmount: number): number => {
  const expectedTotal = payments.length * dailyAmount;
  const actualPaid = calculateTotalPaid(payments);
  return expectedTotal - actualPaid;
};

// Get last paid date for a member
export const getLastPaidDate = (payments: Payment[]): string => {
  const paidPayments = payments.filter(p => p.status === 'paid');
  if (paidPayments.length === 0) return 'Never';
  
  const sortedPayments = [...paidPayments].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );
  
  return sortedPayments[0].date;
};

// Format currency
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount);
};

// Format date
export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-IN', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  }).format(date);
};