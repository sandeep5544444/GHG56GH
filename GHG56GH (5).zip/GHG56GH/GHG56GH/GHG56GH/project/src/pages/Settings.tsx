import React, { useState } from 'react';
import { Save, Download, AlertTriangle, RefreshCw } from 'lucide-react';
import { useApp } from '../context/AppContext';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';

const Settings: React.FC = () => {
  const { members, payments } = useApp();
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  
  const handleBackupData = () => {
    const data = {
      members,
      payments,
      backupDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dailyfin-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  const handleResetData = () => {
    if (confirm('Are you sure you want to reset all data? This cannot be undone!')) {
      localStorage.removeItem('finance-app-members');
      localStorage.removeItem('finance-app-payments');
      window.location.reload();
    }
  };
  
  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600">Configure your application settings</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Application Settings</h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Application Name
              </label>
              <input
                type="text"
                defaultValue="DailyFin"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Currency
              </label>
              <select
                defaultValue="INR"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="INR">Indian Rupee (₹)</option>
                <option value="USD">US Dollar ($)</option>
                <option value="EUR">Euro (€)</option>
                <option value="GBP">British Pound (£)</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Date Format
              </label>
              <select
                defaultValue="dd/mm/yyyy"
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="dd/mm/yyyy">DD/MM/YYYY</option>
                <option value="mm/dd/yyyy">MM/DD/YYYY</option>
                <option value="yyyy-mm-dd">YYYY-MM-DD</option>
              </select>
            </div>
            
            <div className="pt-2">
              <Button 
                variant="primary" 
                className="flex items-center gap-1"
              >
                <Save size={16} />
                <span>Save Settings</span>
              </Button>
            </div>
          </div>
        </Card>
        
        <Card>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Data Management</h2>
          
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-medium text-gray-700 mb-1">Backup Data</h3>
              <p className="text-sm text-gray-500 mb-3">
                Download a backup of all your data. This includes members, payments, and settings.
              </p>
              <Button 
                variant="primary" 
                className="flex items-center gap-1"
                onClick={handleBackupData}
              >
                <Download size={16} />
                <span>Download Backup</span>
              </Button>
            </div>
            
            <div className="pt-4 border-t border-gray-200">
              <h3 className="text-sm font-medium text-gray-700 mb-1">Restore Data</h3>
              <p className="text-sm text-gray-500 mb-3">
                Restore your data from a previous backup file.
              </p>
              <div className="flex items-center gap-2">
                <input
                  type="file"
                  accept=".json"
                  className="block w-full text-sm text-gray-500
                    file:mr-4 file:py-2 file:px-4
                    file:rounded-lg file:border-0
                    file:text-sm file:font-medium
                    file:bg-blue-50 file:text-blue-700
                    hover:file:bg-blue-100"
                />
                <Button variant="outline">
                  Restore
                </Button>
              </div>
            </div>
            
            <div className="pt-4 border-t border-gray-200">
              <h3 className="text-sm font-medium text-red-600 mb-1">Reset Application</h3>
              <p className="text-sm text-gray-500 mb-3">
                This will delete all data and reset the application to its default state.
                This action cannot be undone.
              </p>
              
              {showResetConfirm ? (
                <div className="p-4 border border-red-200 bg-red-50 rounded-lg mb-3">
                  <div className="flex items-start">
                    <AlertTriangle size={20} className="text-red-600 mr-2 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-red-700">Warning: This action cannot be undone</h4>
                      <p className="text-sm text-red-600">
                        All your data including members, payments, and settings will be permanently deleted.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <Button 
                      variant="outline"
                      onClick={() => setShowResetConfirm(false)}
                    >
                      Cancel
                    </Button>
                    <Button 
                      variant="danger"
                      onClick={handleResetData}
                    >
                      Yes, Reset Everything
                    </Button>
                  </div>
                </div>
              ) : (
                <Button 
                  variant="danger" 
                  className="flex items-center gap-1"
                  onClick={() => setShowResetConfirm(true)}
                >
                  <RefreshCw size={16} />
                  <span>Reset Application</span>
                </Button>
              )}
            </div>
          </div>
        </Card>
      </div>
    </Layout>
  );
};

export default Settings;