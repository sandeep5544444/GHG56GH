import React, { useState } from 'react';
import { Users, DollarSign, CalendarCheck, ArrowDownUp, FileText, Download, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';
import Layout from '../components/layout/Layout';
import StatCard from '../components/dashboard/StatCard';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import PaymentList from '../components/payments/PaymentList';
import { calculateDashboardStats } from '../utils/calculations';
import DueReminders from '../components/dashboard/DueReminders'; // Added import statement

const Dashboard: React.FC = () => {
  const { members, payments, addPayment } = useApp();
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [showPaymentForm, setShowPaymentForm] = useState(false);

  const stats = calculateDashboardStats(members, payments);

  // Get today's payments
  const today = new Date().toISOString().split('T')[0];
  const todayPayments = payments
    .filter(p => p.date === today)
    .sort((a, b) => {
      if (a.status === 'paid' && b.status !== 'paid') return -1;
      if (a.status !== 'paid' && b.status === 'paid') return 1;
      return 0;
    });

  const handleSearch = () => {
    const member = members.find(m => 
      m.serialNumber === searchQuery || 
      m.mobileNumber === searchQuery
    );

    if (member) {
      navigate(`/members/${member.id}`);
    } else {
      alert('No member found with the given serial number or mobile number');
    }
  };

  return (
    <Layout>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600">View your daily finance summary</p>
        </div>
        <Button
          variant="primary"
          size="lg"
          onClick={() => setShowPaymentForm(true)}
          className="flex items-center gap-2"
        >
          <DollarSign size={20} />
          <span>Collect Payment</span>
        </Button>
      </div>

      {showPaymentForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-lg m-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Collect Payment</h2>
              <button onClick={() => setShowPaymentForm(false)} className="text-gray-500 hover:text-gray-700">
                ×
              </button>
            </div>
            <PaymentForm
              members={members}
              onSubmit={(data) => {
                addPayment(data);
                setShowPaymentForm(false);
              }}
              onCancel={() => setShowPaymentForm(false)}
            />
          </Card>
        </div>
      )}

      <Card className="mb-6">
        <div className="flex gap-4">
          <div className="flex-1">
            <input
              type="text"
              placeholder="Search by serial number or mobile number..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <Button 
            variant="primary"
            onClick={handleSearch}
            className="flex items-center gap-2"
          >
            <Search size={18} />
            <span>Search</span>
          </Button>
        </div>
      </Card>

      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-5 gap-4 md:gap-6 mb-8">
        <StatCard
          title="Total Members"
          value={stats.totalMembers}
          icon={<Users size={20} />}
        />
        <StatCard
          title="Today's Paid"
          value={`${stats.todayPaidCount} (₹${stats.todayPaidAmount})`}
          icon={<CalendarCheck size={20} />}
        />
        <StatCard
          title="Today's Unpaid"
          value={`${stats.todayUnpaidCount} (₹${stats.todayUnpaidAmount})`}
          icon={<ArrowDownUp size={20} />}
        />
        <StatCard
          title="Monthly Collection"
          value={stats.monthlyCollection}
          isCurrency={true}
          icon={<DollarSign size={20} />}
          trend={{ value: 12, isPositive: true }}
        />
        <StatCard
          title="Total Remaining Loan"
          value={members.reduce((sum, member) => {
            const memberPayments = payments
              .filter(p => p.memberId === member.id && p.status === 'paid')
              .reduce((pSum, p) => pSum + p.amount, 0);
            return sum + (member.loanAmount - memberPayments);
          }, 0)}
          isCurrency={true}
          icon={<DollarSign size={20} />}
        />
      </div>

      <Card className="mb-8">
        <div className="flex items-center justify-center gap-2 p-4">
          <p className="text-lg">Today's Payment Ratio:</p>
          <p className="text-2xl font-bold">
            <span className="text-green-600">{stats.todayPaidCount}</span>
            <span className="mx-1">/</span>
            <span className="text-red-600">{stats.todayUnpaidCount}</span>
            <span className="text-gray-600 ml-2">members</span>
          </p>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <DueReminders />
        <Card className="lg:col-span-2">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Today's Payments</h2>
            <Button variant="outline" size="sm" className="flex items-center gap-1">
              <FileText size={16} />
              <span>View All</span>
            </Button>
          </div>
          <PaymentList payments={todayPayments.slice(0, 5)} members={members} />
        </Card>

        <Card>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Reports</h2>
          </div>
          <div className="space-y-4">
            <Button variant="primary" className="w-full flex items-center justify-center gap-2">
              <Download size={16} />
              <span>Daily Report</span>
            </Button>
            <Button variant="outline" className="w-full flex items-center justify-center gap-2">
              <Download size={16} />
              <span>Monthly Summary</span>
            </Button>
            <Button variant="outline" className="w-full flex items-center justify-center gap-2">
              <Download size={16} />
              <span>Pending Payments</span>
            </Button>
          </div>
        </Card>
      </div>

      <Card>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Reminders</h2>
        </div>
        <div className="p-4 border border-yellow-200 rounded-lg bg-yellow-50">
          <p className="text-yellow-800">
            {stats.todayUnpaidCount} members haven't made their payment today. 
            Consider sending them a reminder.
          </p>
        </div>
      </Card>
    </Layout>
  );
};

export default Dashboard;