import React from 'react';
import { Payment, Member } from '../../types';
import Badge from '../ui/Badge';
import { formatCurrency, formatDate } from '../../utils/calculations';

interface PaymentListProps {
  payments: Payment[];
  members: Member[];
  onEditPayment?: (id: string) => void;
  onDeletePayment?: (id: string) => void;
}

const PaymentList: React.FC<PaymentListProps> = ({
  payments,
  members,
  onEditPayment,
  onDeletePayment
}) => {
  const getMemberName = (memberId: string) => {
    const member = members.find(m => m.id === memberId);
    return member ? member.name : 'Unknown Member';
  };
  
  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Date
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Member
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Amount
            </th>
            <th
              scope="col"
              className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
            >
              Status
            </th>
            {(onEditPayment || onDeletePayment) && (
              <th
                scope="col"
                className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                Actions
              </th>
            )}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {payments.length > 0 ? (
            payments.map(payment => (
              <tr key={payment.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {formatDate(payment.date)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {getMemberName(payment.memberId)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {formatCurrency(payment.amount)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <Badge
                    variant={payment.status === 'paid' ? 'success' : 'warning'}
                  >
                    {payment.status === 'paid' ? 'Paid' : 'Not Paid'}
                  </Badge>
                </td>
                {(onEditPayment || onDeletePayment) && (
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {onEditPayment && (
                      <button 
                        onClick={() => onEditPayment(payment.id)}
                        className="text-blue-600 hover:text-blue-900 mr-4"
                      >
                        Edit
                      </button>
                    )}
                    {onDeletePayment && (
                      <button 
                        onClick={() => onDeletePayment(payment.id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    )}
                  </td>
                )}
              </tr>
            ))
          ) : (
            <tr>
              <td 
                colSpan={(onEditPayment || onDeletePayment) ? 5 : 4}
                className="px-6 py-4 text-center text-sm text-gray-500"
              >
                No payments found
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default PaymentList;