
import { supabase } from '../lib/supabase';

export const DatabaseService = {
  async getMembersList() {
    const { data, error } = await supabase
      .from('members')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) throw error;
    return data || [];
  },
  
  async saveMembersList(members: any[]) {
    const { error } = await supabase
      .from('members')
      .upsert(members, { onConflict: 'id' });
    if (error) throw error;
  },
  
  async getPaymentsList() {
    const { data, error } = await supabase
      .from('payments')
      .select('*')
      .order('date', { ascending: false });
    if (error) throw error;
    return data || [];
  },
  
  async savePaymentsList(payments: any[]) {
    const { error } = await supabase
      .from('payments')
      .upsert(payments, { onConflict: 'id' });
    if (error) throw error;
  }
};
