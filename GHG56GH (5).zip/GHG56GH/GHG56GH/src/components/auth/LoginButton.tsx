
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import Button from '../ui/Button';

export default function LoginButton() {
  const { isLoggedIn, isLoading, error, login, loginWithEmail, signup, logout, user } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignup, setIsSignup] = useState(false);

  if (isLoading) {
    return <Button disabled className="w-full opacity-50">Loading...</Button>;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSignup) {
      await signup(email, password);
    } else {
      await loginWithEmail(email, password);
    }
  };

  if (isLoggedIn) {
    return (
      <Button onClick={logout} variant="outline" className="w-full">
        Sign Out {user?.email && `(${user.email})`}
      </Button>
    );
  }

  return (
    <div className="w-full space-y-4">
      {error && <p className="text-red-500 text-sm">{error}</p>}
      
      <form onSubmit={handleSubmit} className="space-y-3">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          className="w-full p-2 border rounded"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          className="w-full p-2 border rounded"
        />
        <Button type="submit" variant="primary" className="w-full">
          {isSignup ? 'Sign Up' : 'Sign In'}
        </Button>
      </form>

      <div className="text-center">
        <button 
          onClick={() => setIsSignup(!isSignup)} 
          className="text-sm text-blue-500 hover:underline"
        >
          {isSignup ? 'Already have an account? Sign In' : 'Need an account? Sign Up'}
        </button>
      </div>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-gray-300" />
        </div>
        <div className="relative flex justify-center text-sm">
          <span className="px-2 bg-white text-gray-500">Or continue with</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Button onClick={() => login('google')} variant="outline">
          Google
        </Button>
        <Button onClick={() => login('github')} variant="outline">
          GitHub
        </Button>
      </div>
    </div>
  );
}
