import { Member, Payment } from '../types';

// Generate mock members
export const mockMembers: Member[] = [
  {
    id: '1',
    name: 'Rahul Sharma',
    mobileNumber: '9876543210',
    serialNumber: 'M001',
    dailyAmount: 500,
    documents: [
      {
        id: '1',
        name: 'Aadhar Card',
        type: 'aadhar',
        url: 'https://example.com/aadhar1',
        uploadDate: '2023-01-15'
      }
    ],
    notes: 'Regular payer'
  },
  {
    id: '2',
    name: 'Priya Patel',
    mobileNumber: '8765432109',
    serialNumber: 'M002',
    dailyAmount: 750,
    documents: [
      {
        id: '2',
        name: 'PAN Card',
        type: 'pan',
        url: 'https://example.com/pan2',
        uploadDate: '2023-02-20'
      }
    ],
    notes: 'Sometimes pays weekly'
  },
  {
    id: '3',
    name: 'Amit Kumar',
    mobileNumber: '7654321098',
    serialNumber: 'M003',
    dailyAmount: 600,
    documents: [],
    notes: ''
  },
  {
    id: '4',
    name: 'Deepika Singh',
    mobileNumber: '6543210987',
    serialNumber: 'M004',
    dailyAmount: 1000,
    documents: [
      {
        id: '3',
        name: 'Agreement',
        type: 'agreement',
        url: 'https://example.com/agreement4',
        uploadDate: '2023-03-10'
      }
    ],
    notes: 'High value client'
  },
  {
    id: '5',
    name: 'Ravi Verma',
    mobileNumber: '5432109876',
    serialNumber: 'M005',
    dailyAmount: 450,
    documents: [],
    notes: 'New member since April'
  }
];

// Generate mock payments
const today = new Date().toISOString().split('T')[0];
const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
const twoDaysAgo = new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0];

export const mockPayments: Payment[] = [
  // Today's payments
  { id: '1', memberId: '1', date: today, amount: 500, status: 'paid' },
  { id: '2', memberId: '2', date: today, amount: 750, status: 'not_paid' },
  { id: '3', memberId: '3', date: today, amount: 600, status: 'paid' },
  { id: '4', memberId: '4', date: today, amount: 1000, status: 'paid' },
  { id: '5', memberId: '5', date: today, amount: 450, status: 'not_paid' },
  
  // Yesterday's payments
  { id: '6', memberId: '1', date: yesterday, amount: 500, status: 'paid' },
  { id: '7', memberId: '2', date: yesterday, amount: 750, status: 'paid' },
  { id: '8', memberId: '3', date: yesterday, amount: 600, status: 'not_paid' },
  { id: '9', memberId: '4', date: yesterday, amount: 1000, status: 'paid' },
  { id: '10', memberId: '5', date: yesterday, amount: 450, status: 'paid' },
  
  // Two days ago payments
  { id: '11', memberId: '1', date: twoDaysAgo, amount: 500, status: 'paid' },
  { id: '12', memberId: '2', date: twoDaysAgo, amount: 750, status: 'paid' },
  { id: '13', memberId: '3', date: twoDaysAgo, amount: 600, status: 'paid' },
  { id: '14', memberId: '4', date: twoDaysAgo, amount: 1000, status: 'not_paid' },
  { id: '15', memberId: '5', date: twoDaysAgo, amount: 450, status: 'paid' }
];

// Helper function to get all payments for a member
export const getPaymentsForMember = (memberId: string): Payment[] => {
  return mockPayments.filter(payment => payment.memberId === memberId);
};

// Helper function to calculate payment statistics
export const calculateMemberStats = (memberId: string) => {
  const payments = getPaymentsForMember(memberId);
  const totalPaid = payments
    .filter(p => p.status === 'paid')
    .reduce((sum, payment) => sum + payment.amount, 0);
  
  const member = mockMembers.find(m => m.id === memberId);
  const dailyAmount = member?.dailyAmount || 0;
  const totalExpected = dailyAmount * payments.length;
  const pendingAmount = totalExpected - totalPaid;
  
  const lastPaidPayment = [...payments]
    .filter(p => p.status === 'paid')
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())[0];
  
  return {
    totalPaid,
    pendingAmount,
    lastPaidDate: lastPaidPayment?.date || 'Never'
  };
};