import React, { useState } from 'react';
import { PlusCircle, Search } from 'lucide-react';
import { useApp } from '../context/AppContext';
import Layout from '../components/layout/Layout';
import MemberCard from '../components/members/MemberCard';
import MemberForm from '../components/members/MemberForm';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';

const Members: React.FC = () => {
  const { members, addMember } = useApp();
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredMembers = members.filter(member => 
    member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    member.mobileNumber.includes(searchQuery) ||
    member.serialNumber.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  const handleAddMember = (data: any) => {
    addMember({
      ...data,
      documents: []
    });
    setShowAddForm(false);
  };
  
  return (
    <Layout>
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Members</h1>
          <p className="text-gray-600">Manage your members and their details</p>
        </div>
        
        <Button 
          variant="primary"
          className="flex items-center gap-2"
          onClick={() => setShowAddForm(true)}
        >
          <PlusCircle size={18} />
          <span>Add Member</span>
        </Button>
      </div>
      
      <div className="mb-6">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-gray-400" />
          </div>
          <input
            type="text"
            placeholder="Search by name, mobile number or serial number..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>
      
      {showAddForm && (
        <Card className="mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Add New Member</h2>
          <MemberForm 
            onSubmit={handleAddMember} 
            onCancel={() => setShowAddForm(false)} 
          />
        </Card>
      )}
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMembers.length > 0 ? (
          filteredMembers.map(member => (
            <MemberCard key={member.id} member={member} />
          ))
        ) : (
          <div className="col-span-full text-center py-8">
            <p className="text-gray-500">
              {searchQuery ? 'No members found matching your search' : 'No members found. Add your first member!'}
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Members;