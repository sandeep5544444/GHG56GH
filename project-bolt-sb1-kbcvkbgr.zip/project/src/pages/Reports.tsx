import React, { useState } from 'react';
import { Download, FileSpreadsheet, File as FilePdf } from 'lucide-react';
import { useApp } from '../context/AppContext';
import Layout from '../components/layout/Layout';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import ReportFilters, { ReportFilters as FilterType } from '../components/reports/ReportFilters';
import PaymentList from '../components/payments/PaymentList';
import { formatCurrency } from '../utils/calculations';

const Reports: React.FC = () => {
  const { members, payments } = useApp();
  const [filters, setFilters] = useState<FilterType>({
    startDate: new Date(new Date().setDate(1)).toISOString().split('T')[0], // First day of current month
    endDate: new Date().toISOString().split('T')[0], // Today
    paymentStatus: 'all',
    memberId: '',
  });
  
  // Apply filters to payments
  const filteredPayments = payments.filter(payment => {
    // Date range filter
    const paymentDate = new Date(payment.date);
    const startDate = new Date(filters.startDate);
    const endDate = new Date(filters.endDate);
    
    if (paymentDate < startDate || paymentDate > endDate) {
      return false;
    }
    
    // Payment status filter
    if (filters.paymentStatus !== 'all' && payment.status !== filters.paymentStatus) {
      return false;
    }
    
    // Member filter
    if (filters.memberId && payment.memberId !== filters.memberId) {
      return false;
    }
    
    return true;
  });
  
  // Calculate totals
  const totalAmount = filteredPayments.reduce((sum, p) => sum + p.amount, 0);
  const paidAmount = filteredPayments
    .filter(p => p.status === 'paid')
    .reduce((sum, p) => sum + p.amount, 0);
  const unpaidAmount = filteredPayments
    .filter(p => p.status === 'not_paid')
    .reduce((sum, p) => sum + p.amount, 0);
  
  return (
    <Layout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
        <p className="text-gray-600">Generate and download payment reports</p>
      </div>
      
      <ReportFilters onFilterChange={setFilters} />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <h3 className="text-base font-medium text-gray-500 mb-1">Total Amount</h3>
          <p className="text-2xl font-semibold">{formatCurrency(totalAmount)}</p>
        </Card>
        
        <Card>
          <h3 className="text-base font-medium text-gray-500 mb-1">Paid Amount</h3>
          <p className="text-2xl font-semibold text-emerald-600">{formatCurrency(paidAmount)}</p>
        </Card>
        
        <Card>
          <h3 className="text-base font-medium text-gray-500 mb-1">Unpaid Amount</h3>
          <p className="text-2xl font-semibold text-amber-600">{formatCurrency(unpaidAmount)}</p>
        </Card>
      </div>
      
      <Card className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold text-gray-900">Payment Data</h2>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              className="flex items-center gap-1"
            >
              <FilePdf size={16} />
              <span>Export PDF</span>
            </Button>
            <Button 
              variant="primary" 
              className="flex items-center gap-1"
            >
              <FileSpreadsheet size={16} />
              <span>Export Excel</span>
            </Button>
          </div>
        </div>
        
        <PaymentList payments={filteredPayments} members={members} />
      </Card>
      
      <Card>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Saved Reports</h2>
        <div className="space-y-3">
          <div className="p-4 border border-gray-200 rounded-lg flex justify-between items-center">
            <div>
              <h3 className="font-medium">Monthly Collection - June 2025</h3>
              <p className="text-sm text-gray-500">Generated on June 30, 2025</p>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center gap-1"
            >
              <Download size={14} />
              <span>Download</span>
            </Button>
          </div>
          <div className="p-4 border border-gray-200 rounded-lg flex justify-between items-center">
            <div>
              <h3 className="font-medium">Pending Payments Report - Q2 2025</h3>
              <p className="text-sm text-gray-500">Generated on July 1, 2025</p>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center gap-1"
            >
              <Download size={14} />
              <span>Download</span>
            </Button>
          </div>
        </div>
      </Card>
    </Layout>
  );
};

export default Reports;