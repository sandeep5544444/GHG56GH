import React, { useState } from 'react';
import { Upload } from 'lucide-react';
import Button from '../ui/Button';
import { Member } from '../../types';

interface MemberFormProps {
  initialData?: Partial<Member>;
  onSubmit: (data: Omit<Member, 'id' | 'documents'>) => void;
  onCancel: () => void;
}

const MemberForm: React.FC<MemberFormProps> = ({
  initialData = {},
  onSubmit,
  onCancel
}) => {
  const [formData, setFormData] = useState({
    name: initialData.name || '',
    mobileNumber: initialData.mobileNumber || '',
    serialNumber: initialData.serialNumber || '',
    loanAmount: initialData.loanAmount || 0,
    dailyAmount: initialData.dailyAmount || 0,
    profilePicture: initialData.profilePicture || '',
    friendsPicture: initialData.friendsPicture || '',
    notes: initialData.notes || ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    if (name === 'loanAmount') {
      const loanAmount = Number(value);
      const dailyAmount = Math.ceil(loanAmount / 100); // 1% of loan amount
      setFormData(prev => ({ 
        ...prev, 
        [name]: value,
        dailyAmount: dailyAmount
      }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
    
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'profilePicture' | 'friendsPicture') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({
          ...prev,
          [field]: reader.result as string
        }));
      };
      reader.readAsDataURL(file);
    }
  };
  
  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.mobileNumber.trim()) {
      newErrors.mobileNumber = 'Mobile number is required';
    } else if (!/^\d{10}$/.test(formData.mobileNumber)) {
      newErrors.mobileNumber = 'Mobile number must be 10 digits';
    }
    
    if (!formData.serialNumber.trim()) {
      newErrors.serialNumber = 'Serial number is required';
    }
    
    if (formData.loanAmount <= 0) {
      newErrors.loanAmount = 'Loan amount must be greater than 0';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validate()) {
      onSubmit({
        ...formData,
        loanAmount: Number(formData.loanAmount),
        dailyAmount: Number(formData.dailyAmount)
      });
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Profile Picture
          </label>
          <div className="flex items-center space-x-4">
            {formData.profilePicture && (
              <img 
                src={formData.profilePicture} 
                alt="Profile" 
                className="w-24 h-24 rounded-lg object-cover"
              />
            )}
            <div className="flex-1">
              <label className="cursor-pointer block">
                <div className="px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                  <Upload size={16} />
                  <span>Upload Photo</span>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handleFileChange(e, 'profilePicture')}
                />
              </label>
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Friends Picture
          </label>
          <div className="flex items-center space-x-4">
            {formData.friendsPicture && (
              <img 
                src={formData.friendsPicture} 
                alt="Friends" 
                className="w-24 h-24 rounded-lg object-cover"
              />
            )}
            <div className="flex-1">
              <label className="cursor-pointer block">
                <div className="px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                  <Upload size={16} />
                  <span>Upload Photo</span>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => handleFileChange(e, 'friendsPicture')}
                />
              </label>
            </div>
          </div>
        </div>
      </div>

      <div>
        <label 
          htmlFor="name" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Name
        </label>
        <input
          type="text"
          id="name"
          name="name"
          value={formData.name}
          onChange={handleChange}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors.name ? 'border-red-500' : 'border-gray-300'
          }`}
        />
        {errors.name && (
          <p className="mt-1 text-sm text-red-600">{errors.name}</p>
        )}
      </div>
      
      <div>
        <label 
          htmlFor="mobileNumber" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Mobile Number
        </label>
        <input
          type="text"
          id="mobileNumber"
          name="mobileNumber"
          value={formData.mobileNumber}
          onChange={handleChange}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors.mobileNumber ? 'border-red-500' : 'border-gray-300'
          }`}
        />
        {errors.mobileNumber && (
          <p className="mt-1 text-sm text-red-600">{errors.mobileNumber}</p>
        )}
      </div>
      
      <div>
        <label 
          htmlFor="serialNumber" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Serial Number
        </label>
        <input
          type="text"
          id="serialNumber"
          name="serialNumber"
          value={formData.serialNumber}
          onChange={handleChange}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors.serialNumber ? 'border-red-500' : 'border-gray-300'
          }`}
        />
        {errors.serialNumber && (
          <p className="mt-1 text-sm text-red-600">{errors.serialNumber}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label 
            htmlFor="loanAmount" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Loan Amount (₹)
          </label>
          <input
            type="number"
            id="loanAmount"
            name="loanAmount"
            value={formData.loanAmount}
            onChange={handleChange}
            min="0"
            step="1000"
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
              errors.loanAmount ? 'border-red-500' : 'border-gray-300'
            }`}
          />
          {errors.loanAmount && (
            <p className="mt-1 text-sm text-red-600">{errors.loanAmount}</p>
          )}
        </div>

        <div>
          <label 
            htmlFor="dailyAmount" 
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Daily Amount (₹)
          </label>
          <input
            type="number"
            id="dailyAmount"
            name="dailyAmount"
            value={formData.dailyAmount}
            readOnly
            className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
          />
          <p className="mt-1 text-sm text-gray-500">
            Automatically calculated as 1% of loan amount
          </p>
        </div>
      </div>
      
      <div>
        <label 
          htmlFor="notes" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Notes (Optional)
        </label>
        <textarea
          id="notes"
          name="notes"
          value={formData.notes}
          onChange={handleChange}
          rows={3}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      
      <div className="flex justify-end space-x-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button type="submit" variant="primary">
          {initialData.id ? 'Update Member' : 'Add Member'}
        </Button>
      </div>
    </form>
  );
};

export default MemberForm;