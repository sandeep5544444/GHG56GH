import React, { useState } from 'react';
import { Member, Payment } from '../../types';
import Button from '../ui/Button';

interface PaymentFormProps {
  members: Member[];
  onSubmit: (payment: Omit<Payment, 'id'>) => void;
  onCancel: () => void;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ members, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState<Omit<Payment, 'id'>>({
    memberId: '',
    date: new Date().toISOString().split('T')[0],
    amount: 0,
    status: 'paid',
    notes: ''
  });
  
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    
    if (name === 'memberId' && value) {
      // Set default amount based on member's daily amount
      const member = members.find(m => m.id === value);
      if (member) {
        setFormData(prev => ({
          ...prev,
          [name]: value,
          amount: member.dailyAmount
        }));
      } else {
        setFormData(prev => ({ ...prev, [name]: value }));
      }
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
    
    // Clear error when field is edited
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  
  const validate = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.memberId) {
      newErrors.memberId = 'Please select a member';
    }
    
    if (!formData.date) {
      newErrors.date = 'Date is required';
    }
    
    if (formData.amount <= 0) {
      newErrors.amount = 'Amount must be greater than 0';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validate()) {
      onSubmit({
        ...formData,
        amount: Number(formData.amount)
      });
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label 
          htmlFor="memberId" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Select Member
        </label>
        <select
          id="memberId"
          name="memberId"
          value={formData.memberId}
          onChange={handleChange}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors.memberId ? 'border-red-500' : 'border-gray-300'
          }`}
        >
          <option value="">Select a member</option>
          {members.map(member => (
            <option key={member.id} value={member.id}>
              {member.name} - {member.serialNumber}
            </option>
          ))}
        </select>
        {errors.memberId && (
          <p className="mt-1 text-sm text-red-600">{errors.memberId}</p>
        )}
      </div>
      
      <div>
        <label 
          htmlFor="date" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Date
        </label>
        <input
          type="date"
          id="date"
          name="date"
          value={formData.date}
          onChange={handleChange}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors.date ? 'border-red-500' : 'border-gray-300'
          }`}
        />
        {errors.date && (
          <p className="mt-1 text-sm text-red-600">{errors.date}</p>
        )}
      </div>
      
      <div>
        <label 
          htmlFor="amount" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Amount (₹)
        </label>
        <input
          type="number"
          id="amount"
          name="amount"
          value={formData.amount}
          onChange={handleChange}
          min="0"
          step="50"
          className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ${
            errors.amount ? 'border-red-500' : 'border-gray-300'
          }`}
        />
        {errors.amount && (
          <p className="mt-1 text-sm text-red-600">{errors.amount}</p>
        )}
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Payment Status
        </label>
        <div className="flex space-x-4">
          <label className="inline-flex items-center">
            <input
              type="radio"
              name="status"
              value="paid"
              checked={formData.status === 'paid'}
              onChange={handleChange}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2">Paid</span>
          </label>
          <label className="inline-flex items-center">
            <input
              type="radio"
              name="status"
              value="not_paid"
              checked={formData.status === 'not_paid'}
              onChange={handleChange}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2">Not Paid</span>
          </label>
        </div>
      </div>
      
      <div>
        <label 
          htmlFor="notes" 
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Notes (Optional)
        </label>
        <textarea
          id="notes"
          name="notes"
          value={formData.notes || ''}
          onChange={handleChange}
          rows={3}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      
      <div className="flex justify-end space-x-4">
        <Button 
          type="button" 
          variant="outline" 
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button type="submit" variant="primary">
          Record Payment
        </Button>
      </div>
    </form>
  );
};

export default PaymentForm;