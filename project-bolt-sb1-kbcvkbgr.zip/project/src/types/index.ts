export interface Member {
  id: string;
  name: string;
  mobileNumber: string;
  serialNumber: string;
  loanAmount: number;
  dailyAmount: number;
  profilePicture?: string;
  friendsPicture?: string;
  documents: Document[];
  notes: string;
}

export interface Document {
  id: string;
  name: string;
  type: 'aadhar' | 'pan' | 'bank' | 'agreement' | 'other';
  url: string;
  uploadDate: string;
}

export interface Payment {
  id: string;
  memberId: string;
  date: string;
  amount: number;
  status: 'paid' | 'not_paid';
  notes?: string;
}

export interface DashboardStats {
  totalMembers: number;
  todayPaidCount: number;
  todayPaidAmount: number;
  todayUnpaidCount: number;
  todayUnpaidAmount: number;
  monthlyCollection: number;
}